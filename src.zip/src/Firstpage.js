import React, { useEffect, useState } from 'react'
import { useNavigate } from "react-router-dom";
// import LoadingSpinner from './LoadingSpinner';
import './App.css'

export default function Firstpage() {
    const navigate = useNavigate();
    const [isLoding, setIsLoading] = useState(false);

    // useEffect(() => {
    //     setTimeout(() => {
    //         // setIsLoading(true);
    //         navigate('/firstpage')
    //     }, 1000);
    // }, [navigate]);

    function handleClick() {
        setTimeout(() => {
            // setIsLoading(true);
            navigate('/firstpage')
        }, 1000);
    }

    const [blur, setBlur] = useState(false);

    const toggleBlur = () => {
        setBlur(true);
        navigate('/firstpage')
    };

    return (
        <div>
            <div className={`container ${!blur ? 'blurred' : ''}`}>
                <div className="content">
                    {/* <button onClick={handleClick}>button</button>                     */}
                </div>
            </div>


            {!blur &&
                <button onClick={toggleBlur}  id='firstpagebutton'>
                    Toggle Blur
                </button>
            }


        </div>
    )
}
