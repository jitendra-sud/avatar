import React from 'react'

export default function Finalpage() {
  return (
    <div className='container' style={{'background':'white'}}>
       <h1>Thank you for the payment! <br /> Please note, this is a demonstration and the payment gateway information used here is for illustrative purposes only.</h1>
    </div>
  )
}
