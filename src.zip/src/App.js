import React, { Suspense, useEffect, useRef, useState, useMemo } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { useGLTF, useTexture, Loader, Environment, useFBX, useAnimations, OrthographicCamera } from '@react-three/drei';
import { MeshStandardMaterial } from 'three/src/materials/MeshStandardMaterial';

import { LinearEncoding, sRGBEncoding } from 'three/src/constants';
import { LineBasicMaterial, MeshPhysicalMaterial, Vector2 } from 'three';
import ReactAudioPlayer from 'react-audio-player';

import createAnimation from './converter';
import blinkData from './blendDataBlink.json';

import * as THREE from 'three';
import axios from 'axios';
// import { setDeep } from '@react-three/fiber/dist/declarations/src/core/utils';
import './App.css'
import { FaArrowRight } from "react-icons/fa";
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
import NextPage from './NextPage';
import Finalpage from './Finalpage.js';
import Firstpage from './Firstpage.js';


const _ = require('lodash');

const host = 'http://localhost:5000'

function Avatar({ avatar_url,
  speak, setSpeak,
  speakIntro, setSpeakIntro,

  handleWalking,


  playAnime,

  speakGenderGP, setSpeakGenderGP,
  speakDobGP, setSpeakDobGP,
  speakNameGP, setSpeakNameGP,

  speakGenderSpouse, setSpeakGenderSpouse,
  speakDobSpouse, setSpeakDobSpouse,
  speakNameSpouse, setSpeakNameSpouse,

  speakGenderChild, setSpeakGenderChild,
  speakDobChild, setSpeakDobChild,
  speakNameChild, setSpeakNameChild,

  speakresidential, setSpeakResidential,
  speakInvalidMobile, setSpeakInvalidMobile,

  speakName, setSpeakName,
  speakGender, setSpeakGender,
  speakDOB, setSpeakDOB,
  speakNumber, setSpeakNumber,
  speakEmail, setSpeakEmail,
  speakpayment, setSpeakPayment,

  speakProd, setSpeakProd,
  speakPdConfirm, setSpeakPdConfirm,
  text, setAudioSource, playing }) {

  let gltf = useGLTF(avatar_url);
  let morphTargetDictionaryBody = null;
  let morphTargetDictionaryLowerTeeth = null;

  const [
    bodyTexture,
    eyesTexture,
    teethTexture,
    bodySpecularTexture,
    bodyRoughnessTexture,
    bodyNormalTexture,
    teethNormalTexture,
    // teethSpecularTexture,
    hairTexture,
    tshirtDiffuseTexture,
    tshirtNormalTexture,
    tshirtRoughnessTexture,
    hairAlphaTexture,
    hairNormalTexture,
    hairRoughnessTexture,
  ] = useTexture([
    "/images/body.webp",
    "/images/eyes.webp",
    "/images/teeth_diffuse.webp",
    "/images/body_specular.webp",
    "/images/body_roughness.webp",
    "/images/body_normal.webp",
    "/images/teeth_normal.webp",
    // "/images/teeth_specular.webp",
    "/images/h_color.webp",
    "/images/tshirt_diffuse.webp",
    "/images/tshirt_normal.webp",
    "/images/tshirt_roughness.webp",
    "/images/h_alpha.webp",
    "/images/h_normal.webp",
    "/images/h_roughness.webp",
  ]);

  _.each([
    bodyTexture,
    eyesTexture,
    teethTexture,
    teethNormalTexture,
    bodySpecularTexture,
    bodyRoughnessTexture,
    bodyNormalTexture,
    tshirtDiffuseTexture,
    tshirtNormalTexture,
    tshirtRoughnessTexture,
    hairAlphaTexture,
    hairNormalTexture,
    hairRoughnessTexture
  ], t => {
    t.encoding = sRGBEncoding;
    t.flipY = false;
  });

  bodyNormalTexture.encoding = LinearEncoding;
  tshirtNormalTexture.encoding = LinearEncoding;
  teethNormalTexture.encoding = LinearEncoding;
  hairNormalTexture.encoding = LinearEncoding;


  gltf.scene.traverse(node => {


    if (node.type === 'Mesh' || node.type === 'LineSegments' || node.type === 'SkinnedMesh') {

      node.castShadow = true;
      node.receiveShadow = true;
      node.material.envMapIntensity = 0.6;
      if (node.material.map && !node.material.name.includes("hair")) {
        node.material.map.generateMipmaps = false;
      }

      if (node.name.includes("Head_Mesh")) {
        // node.castShadow = true;
        // node.receiveShadow = true;

        // node.material = new MeshPhysicalMaterial();
        // node.material.map = bodyTexture;
        // node.material.shininess = 60;
        // node.material.roughness = 1.7;

        // // node.material.specularMap = bodySpecularTexture;
        // node.material.roughnessMap = bodyRoughnessTexture;
        // node.material.normalMap = bodyNormalTexture;
        // node.material.normalScale = new Vector2(0.6, 0.6);

        morphTargetDictionaryBody = node.morphTargetDictionary;
        // console.log("avatar", morphTargetDictionaryBody)

        // node.material.envMapIntensity = 0.8;
        // node.material.visible = false;

      }

      // if (node.name.includes("Eyes")) {
      //   node.material = new MeshStandardMaterial();
      //   node.material.map = eyesTexture;
      //   // node.material.shininess = 100;
      //   node.material.roughness = 0.1;
      //   node.material.envMapIntensity = 0.5;


      // }

      // if (node.name.includes("Brows")) {
      //   node.material = new LineBasicMaterial({color: 0x000000});
      //   node.material.linewidth = 1;
      //   node.material.opacity = 0.5;
      //   node.material.transparent = true;
      //   node.visible = false;
      // }

      // if (node.name.includes("Wolf3D_Teeth")) {

      //   node.receiveShadow = true;
      //   node.castShadow = true;
      //   node.material = new MeshStandardMaterial();
      //   node.material.roughness = 0.1;
      //   node.material.map = teethTexture;
      //   node.material.normalMap = teethNormalTexture;

      //   node.material.envMapIntensity = 0.7;


      // }

      // if (node.name.includes("Wolf3D_Hair")) {
      //   node.material = new MeshStandardMaterial();
      //   node.material.map = hairTexture;
      //   node.material.alphaMap = hairAlphaTexture;
      //   node.material.normalMap = hairNormalTexture;
      //   node.material.roughnessMap = hairRoughnessTexture;

      //   node.material.transparent = true;
      //   node.material.depthWrite = false;
      //   node.material.side = 2;
      //   node.material.color.setHex(0x000000);

      //   node.material.envMapIntensity = 0.3;


      // }

      // if (node.name.includes("TSHIRT")) {
      //   node.material = new MeshStandardMaterial();

      //   node.material.map = tshirtDiffuseTexture;
      //   node.material.roughnessMap = tshirtRoughnessTexture;
      //   node.material.normalMap = tshirtNormalTexture;
      //   node.material.color.setHex(0xffffff);

      //   node.material.envMapIntensity = 0.5;


      // }

      if (node.name.includes("Teeth_Mesh")) {
        morphTargetDictionaryLowerTeeth = node.morphTargetDictionary;
      }

    }


  });

  const [clips, setClips] = useState([]);
  const mixer = useMemo(() => new THREE.AnimationMixer(gltf.scene), []);

  async function blendDatafunc(blendDataUrl) {
    try {
      // console.log(blendDataUrl);
      let response = await fetch(blendDataUrl);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      let text = await response.json();
      // console.log(text);
      return text;
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error;
    }
  }

  useEffect(() => {
    let blendData = '';
    let fileName = '';

    if (speak === false) return;

    console.log("speakpayment:", speakpayment)
    console.log("speakPdConfirm:", speakPdConfirm)

    if (speakIntro === true) {
      // blendData = '/audioFiles/Introduction/Blenddata/Blendfile.txt';
      // fileName = predata[0].Audio_URL;
      // blendDatafunc(predata[0].Blend_Data)
      //   .then(data => {
      //     blendData = data;
      //     // console.log(blendData)
      //     introflag = true;
      //     precallmakespeech();
      //   })
      //   .catch(error => console.error('Error fetching data:', error));

      blendData = '/audioFiles/introGanesh/Blend_data/Blend_Data.txt';
      fileName = '/Ganesh_Sir_Cloned_Voice.mp3';
    } else if (speakName === true) {
      blendData = '/audioFiles/Name/Name-Blenddata.txt';
      fileName = '/speech-h1rko.mp3';
    } else if (speakNumber === true) {
      blendData = '/audioFiles/Phone Number/phone.txt';
      fileName = '/speech-tpv8z.mp3';
    } else if (speakDOB === true) {
      blendData = '/audioFiles/DOB/DOB-blenddata.txt';
      fileName = '/speech-yabf2.mp3';
    } else if (speakProd === true) {
      console.log("inside recome")
      blendData = '/audioFiles/Reccomendation/reccomendation.txt';
      fileName = '/speech-65j1x.mp3';
    } else if (speakPdConfirm === true) {
      blendData = '/audioFiles/BI_PDF/BlendData.txt';
      fileName = '/speech-ju6df.mp3';
    } else if (speakEmail === true) {
      blendData = '/audioFiles/Email/Email-blenddata.txt';
      fileName = '/speech-q4f0d.mp3';
    } else if (speakInvalidMobile === true) {
      blendData = '/audioFiles/mobile_number/phone_number_validation.txt';
      fileName = '/speech-y779d.mp3';
    } else if (speakpayment === true) {
      console.log("inside payment")
      blendData = '/audioFiles/Redirect/BlendData.txt';
      fileName = '/speech-u6b0o.mp3';
    } else if (speakresidential === true) {
      console.log("speakresidential")
      blendData = '/audioFiles/Residential-Status/Residential-blenddata.txt';
      fileName = '/speech-bj6g5.mp3';
    } else if (speakGender === true) {
      blendData = '/audioFiles/Gender/Gender-blenddata.txt';
      fileName = '/speech-26jbw.mp3';
    }
    else if (speakNameChild === true) {
      blendData = '/audioFiles/CHILD/Name/child-Name-Blenddata.txt';
      fileName = '/speech-l7lq9.mp3';

    } else if (speakDobChild === true) {
      blendData = '/audioFiles/CHILD/DOB/child-DOB-Blenddata.txt';
      fileName = '/speech-nw71n.mp3';
    } else if (speakGenderChild === true) {
      blendData = '/audioFiles/CHILD/Gender/child-Gender-Blenddata.txt';
      fileName = '/speech-ai73b.mp3';
    }
    else if (speakNameSpouse === true) {
      blendData = '/audioFiles/SPOUSE/Name/Spouse-Name-Blenddata.txt';
      fileName = '/speech-gbnq3.mp3';
    } else if (speakDobSpouse === true) {
      blendData = '/audioFiles/SPOUSE/DOB/Spouse-DOB-Blenddata.txt';
      fileName = '/speech-q3zy9.mp3';
    } else if (speakGenderSpouse === true) {
      blendData = '/audioFiles/SPOUSE/Gender/Spouse-Gender-Blenddata.txt';
      fileName = '/speech-dhpu2.mp3';
    }
    else if (speakNameGP === true) {
      blendData = '/audioFiles/GRANDCHILD/Name/grandchild-Name-Blenddata.txt';
      fileName = '/speech-mmzh9.mp3';
    } else if (speakDobGP === true) {
      blendData = '/audioFiles/GRANDCHILD/DOB/grandchildDOB-Blenddata.txt';
      fileName = '/speech-1smbf.mp3';
    } else if (speakGenderGP === true) {
      blendData = '/audioFiles/GRANDCHILD/Gender/grandchild-Gender-Blenddata.txt';
      fileName = '/speech-d1e14.mp3';
    }

    console.log(blendData)
    console.log(fileName)

    makeSpeech(blendData, fileName)
      .then(response => {
        
        let blendData = response.data;
        let filename = response.fileName;

        console.log(blendData)

        let newClips = [
          createAnimation(blendData, morphTargetDictionaryBody, 'Head_Mesh'),
          createAnimation(blendData, morphTargetDictionaryLowerTeeth, 'Teeth_Mesh')
        ];

        filename = 'https://d1dnu0lp2ctxth.cloudfront.net' + filename;


        console.log(filename);
        setClips(newClips);
        setAudioSource(filename);

      })
      .catch(err => {
        console.error(err);
        setSpeak(false);
        setSpeakIntro(false);
        setSpeakName(false);
        setSpeakNumber(false);
        setSpeakDOB(false);
        setSpeakProd(false);
        setSpeakEmail(false);
        setSpeakInvalidMobile(false);
        setSpeakPdConfirm(false);
        setSpeakGender(false);
        setSpeakResidential(false);
        setSpeakPayment(false);
        setSpeakNameChild(false);
        setSpeakDobChild(false)
        setSpeakGenderChild(false)
        setSpeakNameSpouse(false)
        setSpeakDobSpouse(false)
        setSpeakGenderSpouse(false)
        setSpeakNameGP(false)
        setSpeakDobGP(false)
        setSpeakGenderGP(false)
      })

  }, [speak]);

  let idleFbx = useFBX('/Greeting.fbx');
  let { clips: idleClips } = useAnimations(idleFbx.animations);

  let situpFbx = useFBX('/Situps.fbx');
  let { clips: situpClips } = useAnimations(situpFbx.animations);

  let victoryFbx = useFBX('/Victory.fbx');
  let { clips: victoryClips } = useAnimations(victoryFbx.animations);

  let boxingFbx = useFBX('/Boxing.fbx');
  let { clips: boxingClips } = useAnimations(boxingFbx.animations);

  let warmingupFbx = useFBX('/WarmingUp.fbx');
  let { clips: workingupClips } = useAnimations(warmingupFbx.animations);

  let additionalIdleFbx = useFBX('/Idle.fbx');
  let { clips: additionalIdleClips } = useAnimations(additionalIdleFbx.animations);


  let additionalIdleFbx2 = useFBX('/StandingTorchLightTorch.fbx');
  let { clips: additionalIdleClips2 } = useAnimations(additionalIdleFbx2.animations);

  // function handleWalking(){
  //   let idleClipAction = mixer.clipAction(boxingClips[0]);
  //   idleClipAction.play();
  // }

  const handleOnChild = () => {
    console.log("handleOnChild")
  }


  situpClips[0].tracks = _.map(situpClips[0].tracks, track => {

    if (track.name.includes("Head")) {
      track.name = "head.quaternion";
    }

    if (track.name.includes("Neck")) {
      track.name = "neck.quaternion";
    }

    if (track.name.includes("Spine")) {
      track.name = "spine2.quaternion";
    }

    return track;
  });


  // additionalIdleClips[0].tracks = additionalIdleClips[0].tracks.map((track) => {
  //   if (track.name.includes("Head")) {
  //     track.name = "head.quaternion";
  //   }

  //   if (track.name.includes("Neck")) {
  //     track.name = "neck.quaternion";
  //   }

  //   if (track.name.includes("Spine")) {
  //     track.name = "spine2.quaternion";
  //   }

  //   return track;
  // });

  useEffect(() => {

    // let idleClipAction_situp = mixer.clipAction(idleClips[0]);
    // idleClipAction.play();

    let idleClipAction = mixer.clipAction(idleClips[0]);
    // idleClipAction.play();

    let additionalIdleAction = mixer.clipAction(additionalIdleClips[0]);
    // additionalIdleAction.play();

    let additionalIdleAction2 = mixer.clipAction(additionalIdleClips2[0]);
    // additionalIdleAction2.play();

    let blinkClip = createAnimation(blinkData, morphTargetDictionaryBody, 'Head_Mesh');
    let blinkAction = mixer.clipAction(blinkClip);
    blinkAction.play();

    console.log("playAnime:", playAnime)

    if (playing === true) {
      if (playAnime === false) {
        console.log("inside1")
        idleClipAction.stop();
        additionalIdleAction.play();
      }
      else {
        console.log("inside2")
        idleClipAction.stop();
        additionalIdleAction2.play();
      }
    } else {
      // hi animation for 4 sec then stand still
      if (playAnime === false) {
        additionalIdleAction.stop();
        /////
        additionalIdleAction.play()
        // idleClipAction.play();
        console.log("inside3")

        setTimeout(() => {
          idleClipAction.stop();
          additionalIdleAction.play();
        }, 4000);
      } else {
        additionalIdleAction.stop();
        idleClipAction.stop();
        additionalIdleAction2.play();
        console.log("inside4")

        setTimeout(() => {
          // idleClipAction.stop();
          additionalIdleAction2.stop();
          additionalIdleAction.play()
        }, 4000);
      }
    }

  }, [playing, playAnime]);

  // useEffect(() => {

  //   let idleClipAction = mixer.clipAction(idleClips[0]);
  //   // idleClipAction.play();

  //   let additionalIdleAction = mixer.clipAction(additionalIdleClips[0]);
  //   // additionalIdleAction.play();

  //   let additionalIdleAction2 = mixer.clipAction(additionalIdleClips2[0]);
  //   // additionalIdleAction2.play();

  //   let blinkClip = createAnimation(blinkData, morphTargetDictionaryBody, 'Wolf3D_Head');
  //   let blinkAction = mixer.clipAction(blinkClip);
  //   blinkAction.play();

  //   console.log("playAnime:", playAnime)
  //   // if (playAnime === false) {
  //     if (playing === true) {
  //       idleClipAction.stop();
  //       additionalIdleAction.play();
  //     }else {

  //       additionalIdleAction.stop();
  //       idleClipAction.play();

  //       setTimeout(() => {
  //         idleClipAction.stop();
  //         additionalIdleAction.play();
  //       },4000);

  //     }


  //   // else {
  //   //   idleClipAction.stop();
  //   //   additionalIdleAction.stop();
  //   //   additionalIdleAction2.play();

  //   //   setTimeout(() => {
  //   //     additionalIdleAction2.stop()
  //   //     idleClipAction.play();
  //   //   }, 9000);

  //   // }
  // }, [playing]);


  // Play animation clips when available
  useEffect(() => {
    console.log(speak)
    if (playing === false)
      return;

    _.each(clips, clip => {
      let clipAction = mixer.clipAction(clip);
      clipAction.setLoop(THREE.LoopOnce);
      clipAction.play();

    });

  }, [playing]);

  // useEffect(() => {

  //   let idleClipBoxing = mixer.clipAction(boxingClips[0]);
  //   // idleClipBoxing.play();

  //   let idleClipSitup = mixer.clipAction(situpClips[0]);
  //   // idleClipSitup.play();

  //   let idleClipVictory = mixer.clipAction(victoryClips[0]);
  //   // idleClipVictory.play();

  //   let idleClipworkingup = mixer.clipAction(workingupClips[0]);
  //   // idleClipworkingup.play();



  //   let idleClipAction = mixer.clipAction(idleClips[0]);
  //   // idleClipAction.play();

  //   let additionalIdleAction = mixer.clipAction(additionalIdleClips[0]);
  //   // additionalIdleAction.play();

  //   let blinkClip = createAnimation(blinkData, morphTargetDictionaryBody, 'Wolf3D_Head');
  //   let blinkAction = mixer.clipAction(blinkClip);
  //   blinkAction.play();

  //   if (playing === true) {
  //     idleClipAction.stop();
  //     // additionalIdleAction.play();
  //   }
  //   else {
  //     additionalIdleAction.stop();
  //     // idleClipAction.play();
  //   }
  // }, [playing]);

  // // Play animation clips when available
  // useEffect(() => {
  //   console.log(speak)
  //   if (playing === false)
  //     return;

  //   _.each(clips, clip => {
  //     let clipAction = mixer.clipAction(clip);
  //     clipAction.setLoop(THREE.LoopOnce);
  //     clipAction.play();

  //   });

  // }, [playing]);


  useFrame((state, delta) => {
    mixer.update(delta);
  });


  return (
    <group name="avatar" position={[0.05, 1.35, 0]} scale={0.25}>
      <primitive object={gltf.scene} dispose={null} />
    </group>
  );
}


const STYLES = {
  area: { position: 'absolute', bottom: '10px', left: '10px', zIndex: 500 },
  text: { margin: '0px', width: '300px', padding: '5px', background: 'none', color: '#ffffff', fontSize: '1.2em', border: 'none' },
  speak: { padding: '10px', marginTop: '5px', display: 'block', color: '#FFFFFF', background: '#222222', border: 'None' },
  area2: { position: 'absolute', top: '5px', right: '15px', zIndex: 500 },
  label: { color: '#777777', fontSize: '0.8em' }
}

async function makeSpeech(blendData, fileName) {
  try {
    const response = await fetch(blendData); // Accessing the file from the public folder
    console.log(response)
    const data = await response.json();
    console.log(data)
    return {
      "data": data.blendData,
      "fileName": fileName
    }
  } catch (error) {
    console.error('Error fetching data:', error);
  }
  // return axios.post(host + '/talk', { text });
}



function Appp() {
  const audioPlayer = useRef();

  const [speak, setSpeak] = useState(false);
  const [speakIntro, setSpeakIntro] = useState(false);
  const [speakName, setSpeakName] = useState(false);
  const [speakNumber, setSpeakNumber] = useState(false);
  const [speakDOB, setSpeakDOB] = useState(false);
  const [speakPdConfirm, setSpeakPdConfirm] = useState(false);
  const [speakProd, setSpeakProd] = useState(false);
  const [speakEmail, setSpeakEmail] = useState(false);
  const [speakInvalidMobile, setSpeakInvalidMobile] = useState(false);

  const [text, setText] = useState("My name is Arwen. I'm a virtual human who can speak whatever you type here along with realistic facial movements.");
  const [] = useState(null);
  const [playing, setPlaying] = useState(false);

  const [speakNameChild, setSpeakNameChild] = useState(false);
  const [speakDobChild, setSpeakDobChild] = useState(false);
  const [speakGenderChild, setSpeakGenderChild] = useState(false);

  const [speakNameSpouse, setSpeakNameSpouse] = useState(false)
  const [speakDobSpouse, setSpeakDobSpouse] = useState(false);
  const [speakGenderSpouse, setSpeakGenderSpouse] = useState(false);

  const [speakNameGP, setSpeakNameGP] = useState(false);
  const [speakDobGP, setSpeakDobGP] = useState(false);
  const [speakGenderGP, setSpeakGenderGP] = useState(false);

  const [audioSource, setAudioSource] = useState(null);


  // End of play
  function playerEnded(e) {
    setAudioSource(null);

    setSpeak(false);

    setSpeakName(false);
    setSpeakDOB(false)
    setSpeakGender(false)

    setSpeakNameChild(false);
    setSpeakDobChild(false)
    setSpeakGenderChild(false)

    setSpeakNameSpouse(false)
    setSpeakDobSpouse(false)
    setSpeakGenderSpouse(false)

    setSpeakNameGP(false)
    setSpeakDobGP(false)
    setSpeakGenderGP(false)


    setSpeakNumber(false);
    setSpeakEmail(false)
    setSpeakResidential(false)



    setSpeakProd(false)
    setSpeakPdConfirm(false)
    setSpeakIntro(false)
    setSpeakInvalidMobile(false);
    setSpeakPayment(false)


    setPlaying(false);
  }

  // Player is read
  function playerReady(e) {
    audioPlayer.current.audioEl.current.play();
    setPlaying(true);
  }

  // on page reload 
  // useEffect(() => {
  //   setSpeakIntro(true);

  //   // setTimeout(() => {
  //   //   setSpeakIntro(true);
  //   // },1000);

  // }, [])

  // useEffect(() => {
  //   function playerReady(e) {
  //     audioPlayer.current.audioEl.current.play();
  //     setPlaying(true);
  //   }
  //   // setSpeak(true);
  //   setSpeakIntro(true);
  // },[]);



  // const [selectedOptionProduct, setSelectedOptionProoduct] = useState(''); // State to store the selected value
  // const handleSelectChangeProduct = (event) => {
  //   setSelectedOptionProoduct(event.target.value); // Update the selected value in state
  // };

  const [selectedOptionTerm, setSelectedOptionTerm] = useState(''); // State to store the selected value
  const handleSelectChangeTerm = (event) => {
    setSelectedOptionTerm(event.target.value); // Update the selected value in state
  };


  const [selectedOptionPremium, setSelectedOptionPremium] = useState(''); // State to store the selected value
  const handleSelectChangePremium = (event) => {
    setSelectedOptionPremium(event.target.value); // Update the selected value in state
  };

  const [selectedOptionPlan, setSelectedOptionPlan] = useState(''); // State to store the selected value
  const handleSelectChangePlan = (event) => {
    setSelectedOptionPlan(event.target.value); // Update the selected value in state
    // setShowPlan(false);
    // setShowPolicyDuration(true);
  };

  const [selectedOptionPolicyDuration, setSelectedOptionPolicyDuration] = useState('');
  const handleSelectChangePolicyDuration = (event) => {
    setSelectedOptionPolicyDuration(event.target.value);
    setShowPolicyDuration(false);
    setShowPayFor(true);
  }

  const [selectedOptionPayFor, setSelectedOptionPayFor] = useState('');
  const handleSelectChangePayFor = (event) => {
    setSelectedOptionPayFor(event.target.value);
    setShowPayFor(false);
    setShowInvestmentValue(true);
  }



  const [invValue, setInvValue] = useState('');
  const [invFrequency, setInvFrequency] = useState('');

  const [selectedOptionProduct, setSelectedOptionProduct] = useState('');
  const [selectedOptionGender, setSelectedOptionGender] = useState('');
  const [selectedOptionChildGender, setSelectedOptionChildGender] = useState('');
  const [selectedOptionResidentialStatus, setSelectedOptionResidentialStatus] = useState('');

  const [showPopup, setShowPopup] = useState(false);
  const [selectedProductImage, setSelectedProductImage] = useState('');

  const [nameWrn, setNameWrn] = useState(false);
  const [mobWrn, setMobWrn] = useState(false);
  const [dobWrn, setdobWrn] = useState(false);
  const [genderWrn, setGenderWrn] = useState(false);
  const [emailWrn, setemailWrn] = useState(false);
  const [prodDiv, setProdDiv] = useState(false);

  const [showResult, setShowResult] = useState(true);

  // // Page Components
  const [pageNum, setPageNum] = useState(1);

  //Page 2 Components
  const [showname, setShowname] = useState(false);
  const [showmobile, setShowmobile] = useState(false);
  const [showdob, setShowdob] = useState(false);
  const [showemail, setShowemail] = useState(false);
  const [showProduct, setShowProduct] = useState(false);
  const [showPlan, setShowPlan] = useState(false);
  const [showPolicyDuration, setShowPolicyDuration] = useState(false);
  const [showPayFor, setShowPayFor] = useState(false);
  const [showInvestmentValue, setShowInvestmentValue] = useState(false);
  const [showInvestmentFrequency, setShowInvestmentFrequency] = useState(false);
  const [speakresidential, setSpeakResidential] = useState(false);


  const [custName, setCustName] = useState("");
  const [dob, setDob] = useState("");
  const [gender, setGender] = useState('');
  const [selfAge, setSelfAge] = useState("");


  const [custChildName, setCustChildName] = useState("");
  const [childDob, setChildDob] = useState("");
  const [childGender, setChildGender] = useState('');

  const [sopuseAge, setSpouseAge] = useState("");
  const [childAge, setChildAge] = useState("");



  const [mobile, setMobile] = useState("");



  const [email, setEmail] = useState("")
  const [residentialStatus, setResidentialStatus] = useState("");
  const [loaderr, setLoaderr] = useState(false);
  const [policyFor, setPolicyFor] = useState('self');





  //Next Page Function
  const showNxtPage = (num) => {
    setPageNum(pageNum + num);
  };
  //Previous Page Function
  const showPrevPage = (num) => {
    setPageNum(pageNum - num);
  }

  function isValidDOB(dob) {
    const dobDate = new Date(dob);
    const currentDate = new Date();

    if (dobDate >= currentDate) {
      return false;
    }

    return true;
  }

  // Select Gender
  const handleSelectChangeGender = (event) => {
    setGender(event.target.value);
    setSelectedOptionGender(event.target.value);

    setSpeak(true)
    setSpeakGender(true)

    if (custName && dob) {
      showNxtPage(1);
    };
  }

  const handleSelectChangeChildGender = (event) => {
    setChildGender(event.target.value);
    setSelectedOptionChildGender(event.target.value);

    speakChildSposeGPGenderFunc();

    if (custChildName && childDob) {
      showNxtPage(1);
    }
  }
  //select Residential Status
  const handleSelectChangeResidentialStatus = (event) => {
    setResidentialStatus(event.target.value);
    setSelectedOptionResidentialStatus(event.target.value);

    setSpeak(true);
    setSpeakResidential(true);


    if (mobile && email) {
      showNxtPage(1);
      speakResidentialFunc();
    }
  }
  const handleSelectChangetInvFreq = (event) => {
    setInvFrequency(event.target.value)
  }

  const handleSelectChangeProduct = (event) => {
    console.log(event);
    const selectedValue = event.target.value;
    setSelectedOptionProduct(selectedValue);

    // Set the image source based on the selected option
    if (selectedValue === 'option1') {
      setSelectedProductImage('./option1.png');
    } else if (selectedValue === 'option2') {
      setSelectedProductImage('./option2.png');
    }
    // Add conditions for other options as needed
    setShowProduct(false);
    setShowPlan(true);
    setShowPopup(!!selectedValue);
  };

  const closePopup = () => {
    setShowPopup(false);
  };



  function speakNameFunc() {
    setNameWrn(false);

    if (custName.length === 0) {
      setNameWrn(true);
    } else {
      setNameWrn(false);

      setSpeak(true)
      setSpeakName(true);
    }

    if (custName && dob && gender) {
      showNxtPage(1);
    };
  }


  function speakDOBFunc() {
    setdobWrn(false);

    if (dob.length === 0) {
      console.log("insideIf");
      setdobWrn(true);
    } else {
      setdobWrn(false);
      setSpeak(true);
      setSpeakDOB(true);
      // setShowdob(false);
      // setShowemail(true);
    }

    if (custName && dob && gender) {
      showNxtPage(1);
    };

  }


  const [speakGender, setSpeakGender] = useState(false);

  function speakGenderFunc() {
    setGenderWrn(false);
    if (!selectedOptionGender) {
      setGenderWrn(true);
    } else {
      setGenderWrn(false);
      setSpeak(true)
      setSpeakGender(true);
    }
    if (custName && dob && gender) {
      showNxtPage(1);
    };
  }

  ///////////////////////////////////////////////////////////////////////////////////   
  function speakChildSposeGPNameFunc() {
    setNameWrn(false);

    if (custChildName.length === 0) {
      setNameWrn(true);
    } else {
      setNameWrn(false);
      if (policyFor === "Child") {
        setSpeak(true)
        setSpeakNameChild(true);
      } else if (policyFor === "Spouse") {
        setSpeak(true)
        setSpeakNameSpouse(true);
      } else {
        setSpeak(true)
        setSpeakNameGP(true);
      }
    }

    if (custChildName && childDob && childGender) {
      showNxtPage(1);
    };
  }

  function speakChildSposeGPDOBFunc() {
    setNameWrn(false);

    if (childDob.length === 0) {
      setNameWrn(true);
    } else {
      setNameWrn(false);
      if (policyFor === "Child") {
        setSpeak(true)
        setSpeakDobChild(true);
      } else if (policyFor === "Spouse") {
        setSpeak(true)
        setSpeakDobSpouse(true);
      } else {
        setSpeak(true)
        setSpeakDobGP(true);
      }
    }

    if (custChildName && childDob && childGender) {
      showNxtPage(1);
    };
  }



  function speakChildSposeGPGenderFunc() {

    if (policyFor === "Child") {
      setSpeak(true)
      setSpeakGenderChild(true);
    } else if (policyFor === "Spouse") {
      setSpeak(true)
      setSpeakGenderSpouse(true);
    } else {
      setSpeak(true)
      setSpeakGenderGP(true)
    }

  }



  function speakChildDOBFunc() {
    setdobWrn(false);
    console.log("speakDOBFunc:" + dobWrn);
    if (childDob.length === 0) {
      console.log("insideIf");
      setdobWrn(true);
    } else {
      setdobWrn(false);

      setSpeak(true);
      setSpeakDOB(true);
      // setShowdob(false);
      // setShowemail(true);
    }

    if (custChildName && childDob && childGender) {
      showNxtPage(1);
    };

  }


  ////////////////////////////////////////////////////////////////////////


  // Third Page Function
  function speakMobNoFunc() {

    setMobWrn(false);
    if (mobile.length !== 10) {
      setMobWrn(true);
      setSpeak(true);
      setSpeakInvalidMobile(true);
    } else {
      // setShowmobile(false);
      setMobWrn(false);
      setSpeak(true);
      setSpeakNumber(true);

      // setShowdob(true)
    }
    if (mobile && email && residentialStatus) {
      showNxtPage(1);
    }
  }


  function speakEmailFunction() {
    setSpeakEmail(false);
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const isValid = regex.test(email);
    if (!isValid) {
      setemailWrn(true);
    } else {
      setemailWrn(false);
      setSpeak(true);
      setSpeakEmail(true);
    }

    if (mobile && email && residentialStatus) {
      showNxtPage(1);
    }

  }

  function speakResidentialFunc() {
    if (!selectedOptionResidentialStatus) {
      console.log("please enter the rensidential type")
    } else {
      console.log("objectakjishfash")
      setSpeak(true);
      setSpeakResidential(true);
    }

    if (mobile && email && residentialStatus) {
      showNxtPage(1);
    }
  }


  function speakPlanFunc() {

  }

  function speakInvValue() {

  }

  const navigate = useNavigate();

  const [pdfUrl, setPdfUrl] = useState('');


  let globalAgeSelf = "";
  let globalAgeOther = "";


  const formData = {
    "@LI_FNAME": "John",
    "@LI_MNAME": "Doe",
    "@LI_LNAME": "Smith",
    "@LI_ENTRY_AGE": "30",
    "@LI_GENDER": "M",
    "@PROPOSER_FNAME": "Alice",
    "@PROPOSER_MNAME": "Mary",
    "@PROPOSER_LNAME": "Johnson",
    "@PROPOSER_ENTRY_AGE": "31",
    "@PROPOSER_GENDER": "F",
    "@PR_ANNPREM": "100000",
    "@PR_OPTION_1": "1",

    "@LI_ENTRY_DOB": "1993-01-20",
    "@PROPOSER_ENTRY_DOB": "1992-01-20",
    "@PR_MARITAL_STATUS": "1",
    "@PR_EMAIL": "abc@gmail.com",
    "@PR_MOB": "9876543210",
    "@PR_POLICY_FOR": "1",
    "@PR_RESI_STAT": "1"
  }

  //   const formData = {
  //     "@LI_FNAME": "John",
  //     "@LI_MNAME": "Doe",
  //     "@LI_LNAME": "Smith",
  //     "@LI_ENTRY_AGE": "30",
  //     "@LI_GENDER": "M",
  //     "@PROPOSER_FNAME": "Alice",
  //     "@PROPOSER_MNAME": "Mary",
  //     "@PROPOSER_LNAME": "Johnson",
  //     "@PROPOSER_ENTRY_AGE": "35",
  //     "@PROPOSER_GENDER": "F",
  //     "@PR_ANNPREM": "100000",
  //     "@PR_OPTION_1": "1"
  // }

  function settingFormData(policyFor, policyforNumber, liName, ligender, lidob, age) {

    const formData = {
      "@LI_FNAME": liName,
      "@LI_MNAME": "",
      "@LI_LNAME": "",
      "@LI_ENTRY_AGE": "",
      "@LI_GENDER": ligender,
      "@LI_ENTRY_DOB": lidob,

      "@PROPOSER_FNAME": custName,
      "@PROPOSER_MNAME": "",
      "@PROPOSER_LNAME": "",
      "@PROPOSER_ENTRY_AGE": "",
      "@PROPOSER_GENDER": gender,
      "@PROPOSER_ENTRY_DOB": dob,

      "@PR_ANNPREM": invValue,
      "@PR_OPTION_1": selectedOptionPlan,

      "@PR_MARITAL_STATUS": "1",
      "@PR_EMAIL": email,
      "@PR_MOB": mobile,
      "@PR_POLICY_FOR": policyforNumber,
      "@PR_RESI_STAT": residentialStatus
    }

    // console.log(formData)

    return formData;
  }

  let redirectURL = '';
  const [redirectURLtwo, setredirectURltwo] = useState('');

  async function fetchData() {

    let formDataone = {};
    if (policyFor === "Self") formDataone = settingFormData(policyFor, "1", custName, gender, dob, globalAgeSelf);
    else if (policyFor === "Spouse") formDataone = settingFormData(policyFor, "2", custChildName, childGender, childDob, globalAgeOther);
    else if (policyFor === "Child") formDataone = settingFormData(policyFor, "3", custChildName, childGender, childDob, globalAgeOther);
    else formDataone = settingFormData(policyFor, "4", custChildName, childGender, childDob, globalAgeOther);

    console.log(formDataone)


    try {
      const apiurldetails = 'https://dsaguat.sudlife.in/BusinessIllustratorPDF'

      const response = await fetch(apiurldetails, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'BI_Pdf_Wrapper': 'eiyy1het-3x70-aae0-xy67-e22wym2pfg2o',
          'SourceSystem': 'WhatsApp_U101'
        },
        body: JSON.stringify(formDataone),
      })
      const data = await response.json();
      const base64Res = data.Base64Pdf;
      redirectURL = data.Redirect_Link;

      setLoader(false);

      // console.log(redirectURL);

      setredirectURltwo(redirectURL);

      // console.log(redirectURLtwo)

      openImageInNewTab(base64Res);

    } catch (error) {
      console.error('Error fetching data', error);
    }
  }


  const openImageInNewTab = (base64Res) => {
    const binaryData = atob(base64Res);

    console.log(binaryData)

    // console.log(redirectURL);

    const arrayBuffer = new ArrayBuffer(binaryData.length);
    const uint8Array = new Uint8Array(arrayBuffer);

    for (let i = 0; i < binaryData.length; i++) {
      uint8Array[i] = binaryData.charCodeAt(i);
    }
    let blob = new Blob([uint8Array], { type: 'application/pdf' });

    const imageUrl = URL.createObjectURL(blob);

    setPdfUrl(imageUrl);
  };

  const [wait, setWait] = useState('');
  let [paymentDisable, setPaymentDisable] = useState(true);

  const [showpdf, setShowPdf] = useState(true)
  const [showpayment, setShowpayment] = useState(false)
  const [speakPDF, setSpeakPDF] = useState(false);
  const [speakpayment, setSpeakPayment] = useState(false);


  const openPdf = () => {

    if (pdfUrl) {
      setSpeak(true);
      setSpeakPayment(true);
      const newTab = window.open(pdfUrl, '_blank');
      newTab.focus();

      console.log("inside openpdf");

      // showNxtPage(1);

    } else {
      setWait('Please Wait!')

      setTimeout(() => {
        const newTab = window.open(pdfUrl, '_blank');
        newTab.focus();

        setTimeout(() => {
          setSpeak(true);
          setSpeakPayment(true);

          setShowPdf(false);
          setShowpayment(true);
        }, 2000);

      }, 4000)
    }
  };


  const handlePayment = () => {
    setSpeak(true);
    setSpeakPayment(true);

    window.location.href = redirectURL;
    // navigate(redirectURL);
  }

  const [loader, setLoader] = useState(false);

  const handleSubmit = () => {
    setSpeak(true);
    setSpeakPdConfirm(true);
    showNxtPage(1);
    setLoader(true);
    fetchData();
  }


  const calculateAge = (dob, forr) => {
    if (dob.length == 0) return 0;

    const dobDate = new Date(dob);
    const today = new Date();

    let age = today.getFullYear() - dobDate.getFullYear();
    const dobMonth = dobDate.getMonth();
    const todayMonth = today.getMonth();

    if (todayMonth < dobMonth || (todayMonth === dobMonth && today.getDate() < dobDate.getDate())) {
      age--;
    }
    if (age < 0) return age = 0;

    if (forr === "Self") globalAgeSelf = age.toString();
    else globalAgeOther = age.toString();

    return age;
  }

  const showAgeString = () => {
    var str = "Age: " + calculateAge(dob) + " yrs";
    if (policyFor !== 'Self') return `${policyFor}'s ${str}`;
    return str;
  }

  const [blur, setBlur] = useState(false);
  const toggleBlur = () => {
    setBlur(true);
    setSpeak(true);
    setSpeakIntro(true);
  };

  function callAPI() {
    fetchData();
  }

  // let gltf = useGLTF("/new.glb");
  // let morphTargetDictionaryBody = null;
  // let morphTargetDictionaryLowerTeeth = null;


  // gltf.scene.traverse(node => {


  //   if (node.type === 'Mesh' || node.type === 'LineSegments' || node.type === 'SkinnedMesh') {

  //     node.castShadow = true;
  //     node.receiveShadow = true;
  //     node.frustumCulled = false;
  //     // console.log("names of node", node.name)

  //     if (node.name.includes("Wolf3D_Head")) {
  //       morphTargetDictionaryBody = node.morphTargetDictionary;
  //     }



  //     if (node.name.includes("Wolf3D_Teeth")) {
  //       morphTargetDictionaryLowerTeeth = node.morphTargetDictionary;
  //     }

  //   }


  // });

  // const [clips, setClips] = useState([]);
  // const mixer = useMemo(() => new THREE.AnimationMixer(gltf.scene), []);


  // let boxingFbx = useFBX('/Boxing.fbx');
  // let { clips: boxingClips } = useAnimations(boxingFbx.animations);

  // const handleWalkingApp = () =>{
  //   let idleClipAction = mixer.clipAction(boxingClips[0]);
  //   idleClipAction.play();
  // }

  const [playAnime, setPlayAnime] = useState(false);

  const [isChecked, setIsChecked] = useState(false);
  // Function to handle checkbox change
  const handleCheckboxChange = () => {
    setIsChecked(!isChecked);
  };


  const [checkboxes, setCheckboxes] = useState({
    checkbox1: false,
    checkbox2: false,
  });

  const handleCheckboxChangeTwo = (e) => {
    const { name, checked } = e.target;
    setCheckboxes((prevCheckboxes) => ({
      ...prevCheckboxes,
      [name]: checked,
    }));
  };

  const isButtonDisabled = () => {
    const checkedCount = Object.values(checkboxes).filter(Boolean).length;
    return checkedCount < 2;
  };



  const [showPopupp, setShowPopupp] = useState(false);

  const openPopupp = () => {
    setShowPopupp(true);
  };

  const closePopupp = () => {
    setShowPopupp(false);
  };

  const downloadPdf = () => {
    // Construct the URL of the PDF file in the public directory
    const pdfUrl = process.env.PUBLIC_URL + '/Suitability_Analysis_Form_06-Jun-2024_11_28_24.pdf';

    // Create a link element
    const link = document.createElement('a');
    link.href = pdfUrl;
    link.download = 'Suitability_Analysis_Form_06-Jun-2024_11_28_24.pdf'; // Set the filename for download
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  function showNextjurney(){
    showNxtPage(1);
  }

  return (
    <div style={{ 'overflow': 'hidden' }}>

      {/* <div class="typewriter">
        <h1>The cat and the hat.</h1>
      </div> */}

      {!blur &&
        <div style={{ 'display': 'flex', 'justify-content': 'center', 'align-items': 'center', 'flex-wrap': 'wrap' }}>
          <button onClick={toggleBlur} className="blur-button">
            START YOUR AVATAR JOURNEY
          </button>
        </div>
      }

      <div id='main-div' className={` ${!blur ? 'blurred' : ''}`} >
        <div style={{ 'overflow': 'hidden' }}>
          <div className='row'>


            <div className='col-sm' style={{ 'padding': '0vw' }}>

              {/* First Page */}

              {pageNum === 1 &&
                <div className="fadeIn" style={{ 'left': '1vw' }}>
                  {/* Button1 */}

                  {/* <button id="pdf1" onClick={() => { window.open('./images/Brochure.pdf', '_blank'); }} className="btn">
                    Brochure
                  </button> */}

                  {/* Button2 */}

                  {/* <button id="pdf1" onClick={() => { window.open('./images/Plan Details.pdf', '_blank'); }} className="btn">
                    Plan Details
                  </button> */}

                  {/* Button3 */}

                  {/* <button id="pdf1" onClick={() => { window.open('./images/Plan Summary.pdf', '_blank'); }} className="btn">
                    Plan Summary
                  </button> */}

                  {/* <button id="pdf1" onClick={handleOnChild} className="btn">
                    Walking
                  </button>
                  <button id="pdf1" onClick={() => { window.open('./images/Plan Summary.pdf', '_blank'); }} className="btn">
                    Sit-up
                  </button>
                  <button id="pdf1" onClick={() => { window.open('./images/Plan Summary.pdf', '_blank'); }} className="btn">
                    Push-Up
                  </button> */}

                  {/* Next Button */}

                  {/* <button id="pdf1" style={{ 'top': '22vh', 'top': '22vh', 'background': '#75a582', 'color': 'white', 'box-shadow': ' 0 8px 10px hsla(0,0%,100%,.2)' }} className="btn" onClick={() => { showNxtPage(1) }}>
                    Next
                  </button> */}

                  {/* <button id="pdf1" style={{ 'top': '22vh', 'top': '22vh', 'background': '#75a582', 'color': 'white', 'box-shadow': ' 0 8px 10px hsla(0,0%,100%,.2)' }} className="btn" onClick={() => { showNxtPage(1); }}>
                    Next
                  </button> */}

                  {/* setPlayAnime(true); */}


                  {/* <button type='submit' onClick={() => { callAPI() }}>api</button> */}

                </div>
              }

              {pageNum === 2 &&
                <div className="fadeIn" style={{ 'left': '1vw', 'top': '3vw' }}>
                  <p style={{
                    'font-size': '24px',
                    'font-weight': 'bold',
                    'margin-bottom': '20px'
                  }}>Select Policy For:</p>
                  <button className="btn" onClick={() => {
                    setPolicyFor('Self');
                    showNxtPage(1);
                  }}>
                    Self
                  </button>
                  <button className="btn" onClick={() => {
                    setPolicyFor('Spouse');
                    showNxtPage(1);
                  }}>
                    Spouse
                  </button>
                  <button className="btn" onClick={() => {
                    setPolicyFor('Child');
                    showNxtPage(1);
                  }}>
                    Child
                  </button>
                  <button className="btn" onClick={() => {
                    setPolicyFor('GrandChild');
                    showNxtPage(1);
                  }}>
                    GrandChild
                  </button>
                  <button className="btn" onClick={() => { showPrevPage(1) }}>
                    Back
                  </button>
                </div>
              }

              {pageNum === 3 &&

                <div className="fadeIn" style={{ 'left': '1vw', 'top': '3vh' }}>
                  <div>
                    <div id="firstbox" >
                      <input type="text" placeholder="Your Name" onChange={(e) => setCustName(e.target.value)} value={custName} />
                      <button onClick={speakNameFunc} id="arrow">  <FaArrowRight /></button>
                    </div>
                    {nameWrn &&
                      <div id="nameWarning">Please Provide Name!!</div>
                    }
                  </div>

                  <div>
                    <div id="firstbox" >
                      {/* Agar zarurat ho validation ki if (isValidDOB(e.target.value))  */}
                      <input type="date" className="date-input" placeholder="DOB..." onChange={(e) => { setDob(e.target.value) }} value={dob} />
                      <button onClick={speakDOBFunc} id="arrow">  <FaArrowRight /></button>
                    </div>
                    {dobWrn &&
                      <div id="nameWarning">Please Provide DOB!!</div>
                    }
                  </div>

                  <div id="agebox" >
                    <input type="text" placeholder="Age" value={"Age: " + calculateAge(dob, "Self") + " yrs"} />
                  </div>

                  <div style={{ 'height': '7vh', 'margin': '0.5vh 0vw 3vh 2vw' }}>
                    <select id="product" value={selectedOptionGender} onChange={handleSelectChangeGender}>
                      <option value="" disabled selected hidden>Gender</option>
                      <option value="M">Male</option>
                      <option value="F">Female</option>
                      <option value="T">Others</option>
                    </select>
                  </div>
                  {/* <button style={{
                      'top': '-0.1vh',
                      'left': '41vw',
                      'position': 'absolute'
                    }} onClick={speakGenderFunc} id="arrow">  <FaArrowRight /></button> */}

                  {/* <div style={{ 'display': 'flex', 'flex-flow': 'row wrap' }}>
                    <button className="btn" style={{
                      'width': 'calc(40vw + 30px)',
                      'margin-left': '2vw'
                    }} onClick={() => { showPrevPage(1); console.log(pageNum === 'Self' + 4); }}>
                      Back
                    </button>
                  </div> */}
                  {/* <div style={{ 'display': 'flex', 'flex-flow': 'row wrap' }}>
                    <button className="btn" style={{
                      'width': 'calc(40vw + 30px)',
                      'margin-left': '2vw',
                      'background-color': '#75a582'
                    }} onClick={() => { if(custName && dob && gender)showNxtPage(1); }}>
                      Proceed
                    </button> */}
                  <div style={{ 'display': 'flex', 'flex-flow': 'row wrap', 'height': '7vw', 'width': 'calc(40vw + 36px', 'margin': '0.5vh 0vw 3vh 2vw' }}>
                    <button className="btn" style={{ 'width': '20vw', 'margin-right': '18px' }} onClick={() => { showPrevPage(1) }}>
                      Back
                    </button>
                    <button className='btn' id="submit" style={{ 'width': '20vw', 'margin-left': '18px' }} onClick={() => { if (custName && dob && gender) showNxtPage(1); }}>Proceed</button>
                  </div>
                </div>

              }

              {policyFor !== 'Self' && pageNum === 4 &&

                <div className="fadeIn" style={{ 'left': '1vw', 'top': '3vh' }}>
                  <div>
                    <div id="firstbox" >
                      <input type="text" placeholder={policyFor === 'Self' ? 'Name...' : `${policyFor}'s Name...`} onChange={(e) => setCustChildName(e.target.value)} />
                      <button onClick={speakChildSposeGPNameFunc} id="arrow">  <FaArrowRight /></button>
                    </div>
                    {nameWrn &&
                      <div id="nameWarning">Please Provide Name!!</div>
                    }
                  </div>
                  <div>
                    <div id="firstbox" >
                      {/* Agar zarurat ho validation ki if (isValidDOB(e.target.value))  */}
                      <input type="date" className="date-input" placeholder={policyFor === 'Self' ? 'DOB...' : `${policyFor}'s DOB...`} value={childDob} onChange={(e) => { setChildDob(e.target.value) }} />
                      <button onClick={speakChildSposeGPDOBFunc} id="arrow">  <FaArrowRight /></button>
                    </div>
                    {dobWrn &&
                      <div id="nameWarning">Please Provide DOB!!</div>
                    }
                  </div>

                  <div id="agebox" >
                    <input type="text" placeholder="Age" value={"Age: " + calculateAge(childDob, "Other") + " yrs"} />
                  </div>

                  {/* <div id="agebox">
                    <input
                      type="text"
                      value={showAgeString()} />
                  </div> */}

                  <div style={{ 'height': '7vh', 'margin': '0.5vh 0vw 3vh 2vw' }}>
                    <select id="product" value={selectedOptionChildGender} onChange={handleSelectChangeChildGender}>
                      <option value="" disabled selected hidden>{policyFor === 'Self' ? 'Gender' : `${policyFor}'s Gender`}</option>
                      <option value="M">Male</option>
                      <option value="F">Female</option>
                      <option value="T">Other</option>
                    </select>
                    {/* <button onClick={speakGenderFunc} id="arrow">  <FaArrowRight /></button> */}
                  </div>
                  {/* <div style={{ 'display': 'flex', 'flex-flow': 'row wrap' }}>
                    <button className="btn" onClick={() => { showPrevPage(1) }}>
                      Back
                    </button>
                  </div> */}
                  <div style={{ 'display': 'flex', 'flex-flow': 'row wrap', 'height': '7vw', 'width': 'calc(40vw + 36px', 'margin': '0.5vh 0vw 3vh 2vw' }}>
                    <button className="btn" style={{ 'width': '20vw', 'margin-right': '18px' }} onClick={() => { showPrevPage(1) }}>
                      Back
                    </button>
                    <button className='btn' id="submit" style={{ 'width': '20vw', 'margin-left': '18px' }} onClick={() => { if (custChildName && childDob && childGender) showNxtPage(1); }}>Proceed</button>
                  </div>

                </div>
              }

              {pageNum === (4 + (policyFor !== 'Self')) &&
                <div className='fadeIn' style={{ 'left': '1vw' }}>
                  <div>
                    <div id="firstbox" >
                      <input type="mobile" placeholder="Mobile Number..." onChange={(e) => setMobile(e.target.value)} value={mobile} />
                      <button onClick={speakMobNoFunc} id="arrow">  <FaArrowRight /></button>
                    </div>
                    {mobWrn &&
                      <div id="nameWarning">Please Provide Valid Mobile Number!!</div>
                    }
                  </div>
                  <div>
                    <div id="firstbox" >
                      <input type="email" placeholder="Email id..." onChange={(e) => setEmail(e.target.value)} value={email} />
                      <button onClick={speakEmailFunction} id="arrow">  <FaArrowRight /></button>
                    </div>
                    {/* <button type="submit">Search</button> */}
                    {emailWrn &&
                      <div id="nameWarning">Please Provide Email!!</div>
                    }

                  </div>
                  <div style={{ 'height': '7vh', 'margin': '0.5vh 0vw 3vh 2vw' }}>

                    <select id="product" value={selectedOptionResidentialStatus} onChange={handleSelectChangeResidentialStatus}>
                      <option value="" disabled selected hidden>Residential Status</option>
                      <option value="1">Indian</option>
                      <option value="2">NRI/POI/OCI</option>
                    </select>
                    {/* <button id="arrow" onClick={speakResidentialFunc}>  <FaArrowRight /></button> */}
                  </div>

                  {/* <button style={{
                    'width': 'calc(40vw + 30px)',
                    'margin-left': '2vw'
                  }} className="btn" onClick={() => { showPrevPage(1) }}>
                    Back
                  </button> */}

                  <div style={{ 'display': 'flex', 'flex-flow': 'row wrap', 'height': '7vw', 'width': 'calc(40vw + 36px', 'margin': '0.5vh 0vw 3vh 2vw' }}>
                    <button className="btn" style={{ 'width': '20vw', 'margin-right': '18px' }} onClick={() => { showPrevPage(1) }}>
                      Back
                    </button>
                    <button className='btn' id="submit" style={{ 'width': '20vw', 'margin-left': '18px' }} onClick={() => { if (mobile && email && selectedOptionResidentialStatus) showNxtPage(1); }}>Proceed</button>
                  </div>
                </div>
              }




              {pageNum === (5 + (policyFor !== 'Self')) &&

                <div className="fadeIn" style={{ 'left': '-3vw' }}>

                  <div style={{ 'height': '7vh', 'margin': '0.5vh 0vw 3vh 2vw' }}>
                    <select id="product" value={selectedOptionPlan} onChange={handleSelectChangePlan}>
                      <option value="" disabled selected hidden>Select A Plan</option>
                      <option value="1">Option 1</option>
                      <option value="2">Option 2</option>
                    </select>
                    {/* <button id="arrow" onClick={speakPlanFunc}>  <FaArrowRight /></button> */}
                  </div>
                  <div>
                    <div id="firstbox">
                      <input type="text" style={{ 'width': ' calc(40vw + 36px)' }} placeholder="Investment Value" onChange={e => { setInvValue(e.target.value); }} value={invValue} />
                    </div>
                  </div>
                  <div style={{ 'display': 'flex', 'flex-flow': 'row wrap', 'height': '7vw', 'width': 'calc(40vw + 36px', 'margin': '0.5vh 0vw 3vh 2vw', 'position': 'relative', 'top': '-4vh' }}>
                    <button className="btn" style={{ 'width': '20vw', 'margin-right': '18px' }} onClick={() => { showPrevPage(1) }}>
                      Back
                    </button>
                    <button className='btn' id="submit" style={{ 'width': '20vw', 'margin-left': '18px' }} disabled={isButtonDisabled()}
                      onClick={handleSubmit}>Proceed</button>
                  </div>
                  <div style={{
                    'position': 'relative',
                    'top': '5vh',
                    'width': '59vw',
                    'left': '4vw'
                  }}>
                    <input
                      type="checkbox"
                      name="checkbox1"
                      checked={checkboxes.checkbox1}
                      onChange={handleCheckboxChangeTwo}
                      style={{
                        'position': 'relative',
                        'top': '-28vh',
                        'left': '2vw'
                      }}
                    />
                    <label style={{
                      'position': 'relative',
                      'width': ' 30vh',
                      'left': '-2vw'
                    }} >I hereby consent to receive policy related communication from SUD Life Insurance Co. Ltd or its authorized representatives via Call, SMS, Email & Voice over Internet Protocol (VoIP) including WhatsApp</label>

                    <input
                      type="checkbox"
                      name="checkbox2"
                      checked={checkboxes.checkbox2}
                      onChange={handleCheckboxChangeTwo}
                      style={{
                        'position': 'relative',
                        'top': '1vh',
                        'left': '1vw'
                      }}
                    />
          
                    <label style={{
                      'position': 'relative',
                      'width': ' 35vh',
                      'left': '1vw',
                      'top': '0vh'
                    }}>
                      To undergo suitability analysis, please
                      <button onClick={openPopupp} style={{
                        'color': 'blue',
                        'textDecoration': 'underline',
                        'cursor': 'pointer',
                        'border': 'none',
                        'background': 'none',
                        'padding': '0',
                        'font': 'inherit'
                      }}> click here</button>.
                      By selecting the check box, you declare to consciously bypass the recommended suitability analysis module and purchase the policy based on your independent assessment.
                    </label>

                    {showPopupp && <Popup onClose={closePopupp} onDownload={downloadPdf} />}

                  </div>


                </div>
              }

              {pageNum === (6 + (policyFor !== 'Self')) &&
                <>
                  <div>
                    <button className='btn' id="pdfbutton" onClick={openPdf}>BI PDF GENERATE</button>

                    <div style={{
                      'position': 'relative',
                      'top': '11vh',
                      'left': '9vw',
                      'width': '91vw'
                    }}>
                      <input
                        type="checkbox"
                        id="enableButtonCheckbox"
                        checked={isChecked}
                        onChange={handleCheckboxChange}
                      />

                      <label htmlFor="enableButtonCheckbox">By selecting this checkbox, I agree and confirm that I have read and understood the Electronic Benefit Illustration (EBI) and wish to proceed to purchase the policy.</label>

                      {/* <button className='btn' id="submit" style={{
                        'width': '20vw',
                        'position': 'relative',
                        'top': '-29vh',
                        'left': '68vw',
                        'box-shadow': '0 8px 10px hsl(0deg 7.11% 3.61% / 20%)'
                      }} disabled={!isChecked}
                        onClick={showNxtPage(1)}>Proceed</button> */}

                        <button disabled={!isChecked} onClick={showNextjurney} >Proceed</button>

                    </div>


                    {loader &&
                      <>
                        <img id="loader" src="XOsX.gif" alt="loader" />
                      </>
                    }

                  </div>
                  {/* 
                
                <button className="btn" style={{ 'width': '12vw' }} onClick={showPrevPage}>
                      Back
                </button> */}
                </>

              }

              {pageNum === (7 + (policyFor !== 'Self')) &&
                <>

                  <a className='btn btn-primary' id="paymentbutton" href={redirectURLtwo}>Click here for further journey</a>



                  {/* <button className='btn btn-primary' id="paymentbutton" onClick={handlePayment}>Click here for further journey</button> */}
                  {/* <button className="btn" style={{ 'width': '12vw' }} onClick={showPrevPage}>
                      Back
                </button> */}
                </>


              }

              {loaderr &&
                <>
                  <img id="loader" src="XOsX.gif" alt="loader" />
                </>
              }



              <div className='col-lg' style={{ display: 'flex', 'align-items': 'center', 'justify-content': 'center' }}>

                <ReactAudioPlayer
                  src={audioSource}
                  ref={audioPlayer}
                  onEnded={playerEnded}
                  onCanPlayThrough={playerReady}
                />

                <Canvas id="canvas" style={{ 'top': '4vh', 'width': '93%', 'left': '1vw' }} dpr={2} onCreated={(ctx) => {
                  ctx.gl.physicallyCorrectLights = true;
                }}>

                  <OrthographicCamera
                    makeDefault
                    zoom={1500}
                    position={[0.06, 1.65, 0.5]}
                  />

                  {/* <OrbitControls
                        target={[0, 1.65, 0]}
                  /> */}

                  <Suspense fallback={null}>
                    <Environment background={false} files="/images/photo_studio_loft_hall_1k.hdr" />
                  </Suspense>

                  {/* <Suspense fallback={null}>
                    <Bg />
                  </Suspense> */}

                  <Suspense fallback={null}>



                    <Avatar
                      // avatar_url="/model_test.glb"
                      // avatar_url="/new.glb"
                      avatar_url="/modelganesh.glb"
                      speak={speak}
                      setSpeak={setSpeak}


                      // handleWalking={handleWalking}

                      playAnime={playAnime}

                      speakName={speakName}
                      setSpeakName={setSpeakName}

                      speakNumber={speakNumber}
                      setSpeakNumber={setSpeakNumber}

                      speakDOB={speakDOB}
                      setSpeakDOB={setSpeakDOB}

                      speakProd={speakProd}
                      setSpeakProd={setSpeakProd}

                      speakPdConfirm={speakPdConfirm}
                      setSpeakPdConfirm={setSpeakPdConfirm}

                      speakIntro={speakIntro}
                      setSpeakIntro={setSpeakIntro}

                      speakEmail={speakEmail}
                      setSpeakEmail={setSpeakEmail}

                      speakInvalidMobile={speakInvalidMobile}
                      setSpeakInvalidMobile={setSpeakInvalidMobile}

                      speakGender={speakGender}
                      setSpeakGender={setSpeakGender}

                      speakresidential={speakresidential}
                      setSpeakResidential={setSpeakResidential}

                      speakpayment={speakpayment}
                      setSpeakPayment={setSpeakPayment}

                      speakNameChild={speakNameChild}
                      setSpeakNameChild={setSpeakNameChild}

                      speakDobChild={speakDobChild}
                      setSpeakDobChild={setSpeakDobChild}

                      speakGenderChild={speakGenderChild}
                      setSpeakGenderChild={setSpeakGenderChild}

                      speakNameSpouse={speakNameSpouse}
                      setSpeakNameSpouse={setSpeakNameSpouse}

                      speakDobSpouse={speakDobSpouse}
                      setSpeakDobSpouse={setSpeakDobSpouse}

                      speakGenderSpouse={speakGenderSpouse}
                      setSpeakGenderSpouse={setSpeakGenderSpouse}

                      speakNameGP={speakNameGP}
                      setSpeakNameGP={setSpeakNameGP}

                      speakDobGP={speakDobGP}
                      setSpeakDobGP={setSpeakDobGP}

                      speakGenderGP={speakGenderGP}
                      setSpeakGenderGP={setSpeakGenderGP}

                      text={text}
                      setAudioSource={setAudioSource}
                      playing={playing}
                    />


                  </Suspense>


                </Canvas>

              </div>
            </div>


          </div>


          <Loader dataInterpolation={(p) => `Loading... please wait`} />

        </div>

      </div>
    </div>
  )
}

// import Finalpage from './Finalpage.js';


function Popup({ onClose, onDownload }) {
  return (
    <div className="popup" id="consentPopUp">
      <div className="popup-content">
        <p>Please take a printout of the Suitability Analysis Form, fill it up and upload the same in Document Upload page</p>
        <button onClick={onDownload}>Download PDF</button>
      </div>
      <button className="close-btn" onClick={onClose}>Close</button>
    </div>
  );
}

function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/firstpage" element={<Appp />}></Route>
        <Route path="/nextpage" element={<NextPage />}></Route>
        <Route path="/finalpage" element={<Finalpage />}></Route>
        <Route path="/" element={<Firstpage />}></Route>

      </Routes>
    </BrowserRouter>
  )
}

function Bg() {

  const texture = useTexture('/images/bggrey.png');
  const viewport = useThree((state) => state.viewport);

  return (
    <mesh position={[0, 1.65, -1]} scale={[1, 1, 1]}>
      {/* <planeBufferGeometry /> */}
      <planeGeometry args={[viewport.width, viewport.height]} />
      <meshBasicMaterial map={texture} />

    </mesh>
  )

}

export default App;
