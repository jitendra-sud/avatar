import React, { Suspense, useEffect, useRef, useState, useMemo } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { useGLTF, useTexture, Loader, Environment, useFBX, useAnimations, OrthographicCamera } from '@react-three/drei';
import { MeshStandardMaterial } from 'three/src/materials/MeshStandardMaterial';

import { LinearEncoding, sRGBEncoding } from 'three/src/constants';
import { LineBasicMaterial, MeshPhysicalMaterial, Vector2 } from 'three';
import ReactAudioPlayer from 'react-audio-player';

import createAnimation from './converter.js';
import blinkData from './blendDataBlink.json';

import * as THREE from 'three';

// import { setDeep } from '@react-three/fiber/dist/declarations/src/core/utils';
import './App.css'
import { FaArrowRight } from "react-icons/fa";

import { BrowserRouter, Routes, Route, useNavigate, useLocation } from "react-router-dom";


const _ = require('lodash');

const host = 'https://d1dnu0lp2ctxth.cloudfront.net/Audios'

function Avatar({ avatar_url, speak, setSpeak, speakpayment, setSpeakPayment, speakPDF, setSpeakPDF, text, setAudioSource, playing }) {

    let gltf = useGLTF(avatar_url);
    let morphTargetDictionaryBody = null;
    let morphTargetDictionaryLowerTeeth = null;

    const [
        bodyTexture,
        eyesTexture,
        teethTexture,
        bodySpecularTexture,
        bodyRoughnessTexture,
        bodyNormalTexture,
        teethNormalTexture,
        // teethSpecularTexture,
        hairTexture,
        tshirtDiffuseTexture,
        tshirtNormalTexture,
        tshirtRoughnessTexture,
        hairAlphaTexture,
        hairNormalTexture,
        hairRoughnessTexture,
    ] = useTexture([
        "/images/body.webp",
        "/images/eyes.webp",
        "/images/teeth_diffuse.webp",
        "/images/body_specular.webp",
        "/images/body_roughness.webp",
        "/images/body_normal.webp",
        "/images/teeth_normal.webp",
        // "/images/teeth_specular.webp",
        "/images/h_color.webp",
        "/images/tshirt_diffuse.webp",
        "/images/tshirt_normal.webp",
        "/images/tshirt_roughness.webp",
        "/images/h_alpha.webp",
        "/images/h_normal.webp",
        "/images/h_roughness.webp",
    ]);

    _.each([
        bodyTexture,
        eyesTexture,
        teethTexture,
        teethNormalTexture,
        bodySpecularTexture,
        bodyRoughnessTexture,
        bodyNormalTexture,
        tshirtDiffuseTexture,
        tshirtNormalTexture,
        tshirtRoughnessTexture,
        hairAlphaTexture,
        hairNormalTexture,
        hairRoughnessTexture
    ], t => {
        t.encoding = sRGBEncoding;
        t.flipY = false;
    });

    bodyNormalTexture.encoding = LinearEncoding;
    tshirtNormalTexture.encoding = LinearEncoding;
    teethNormalTexture.encoding = LinearEncoding;
    hairNormalTexture.encoding = LinearEncoding;


    gltf.scene.traverse(node => {


        if (node.type === 'Mesh' || node.type === 'LineSegments' || node.type === 'SkinnedMesh') {

            node.castShadow = true;
            node.receiveShadow = true;
            node.frustumCulled = false;

            if (node.name.includes("Wolf3D_Head")) {
                // console.log("here")
                // node.castShadow = true;
                // node.receiveShadow = true;

                // node.material = new MeshPhysicalMaterial();
                // node.material.map = bodyTexture;
                // node.material.shininess = 60;
                // node.material.roughness = 1.7;

                // // node.material.specularMap = bodySpecularTexture;
                // node.material.roughnessMap = bodyRoughnessTexture;
                // node.material.normalMap = bodyNormalTexture;
                // node.material.normalScale = new Vector2(0.6, 0.6);

                morphTargetDictionaryBody = node.morphTargetDictionary;
                // console.log("avatar", morphTargetDictionaryBody)

                // node.material.envMapIntensity = 0.8;
                // node.material.visible = false;

            }

            // if (node.name.includes("Eyes")) {
            //   node.material = new MeshStandardMaterial();
            //   node.material.map = eyesTexture;
            //   // node.material.shininess = 100;
            //   node.material.roughness = 0.1;
            //   node.material.envMapIntensity = 0.5;


            // }

            // if (node.name.includes("Brows")) {
            //   node.material = new LineBasicMaterial({color: 0x000000});
            //   node.material.linewidth = 1;
            //   node.material.opacity = 0.5;
            //   node.material.transparent = true;
            //   node.visible = false;
            // }

            // if (node.name.includes("Wolf3D_Teeth")) {

            //   node.receiveShadow = true;
            //   node.castShadow = true;
            //   node.material = new MeshStandardMaterial();
            //   node.material.roughness = 0.1;
            //   node.material.map = teethTexture;
            //   node.material.normalMap = teethNormalTexture;

            //   node.material.envMapIntensity = 0.7;


            // }

            // if (node.name.includes("Wolf3D_Hair")) {
            //   node.material = new MeshStandardMaterial();
            //   node.material.map = hairTexture;
            //   node.material.alphaMap = hairAlphaTexture;
            //   node.material.normalMap = hairNormalTexture;
            //   node.material.roughnessMap = hairRoughnessTexture;

            //   node.material.transparent = true;
            //   node.material.depthWrite = false;
            //   node.material.side = 2;
            //   node.material.color.setHex(0x000000);

            //   node.material.envMapIntensity = 0.3;


            // }

            // if (node.name.includes("TSHIRT")) {
            //   node.material = new MeshStandardMaterial();

            //   node.material.map = tshirtDiffuseTexture;
            //   node.material.roughnessMap = tshirtRoughnessTexture;
            //   node.material.normalMap = tshirtNormalTexture;
            //   node.material.color.setHex(0xffffff);

            //   node.material.envMapIntensity = 0.5;


            // }

            if (node.name.includes("Wolf3D_Teeth")) {
                morphTargetDictionaryLowerTeeth = node.morphTargetDictionary;
            }

        }

    });

    const [clips, setClips] = useState([]);
    const mixer = useMemo(() => new THREE.AnimationMixer(gltf.scene), []);

    useEffect(() => {
        let blendData = '';
        let fileName = '';

        if (speak === false) return;

        console.log("speak" ,speak)


        if (speakPDF === true) {
            blendData = '/audioFiles/BI-PDF/BI-Blenddata.txt';
            fileName = '/speech-78u4e.mp3';
        }else if (speakpayment === true) {
            console.log("insidepayemtn")
            blendData = '/audioFiles/Payment/payment.txt';
            fileName = '/speech-zgutq.mp3';
        }

        makeSpeech(blendData, fileName)
            .then(response => {
                console.log(response)

                // console.log(response.data.fileName)

                let blendData = response.data.blendData;
                let filename = response.fileName;

                let newClips = [
                    createAnimation(blendData, morphTargetDictionaryBody, 'Wolf3D_Head'),
                    createAnimation(blendData, morphTargetDictionaryLowerTeeth, 'Wolf3D_Teeth')
                ];

                filename = host + filename;

                console.log(filename)

                setClips(newClips);
                setAudioSource(filename);

            })
            .catch(err => {
                console.error(err);
                setSpeak(false);
                setSpeakPDF(false);
                setSpeakPayment(false);
            })


    }, [speak]);

    let idleFbx = useFBX('/Standing_Greeting.fbx');
    let { clips: idleClips } = useAnimations(idleFbx.animations);

    let additionalIdleFbx = useFBX('/Standing.fbx');
    let { clips: additionalIdleClips } = useAnimations(additionalIdleFbx.animations);


    additionalIdleClips[0].tracks = additionalIdleClips[0].tracks.map((track) => {
        // Modify track names based on your model's bone structure
        if (track.name.includes("Head")) {
            // console.log("done")
            track.name = "head.quaternion";
        }

        if (track.name.includes("Neck")) {
            track.name = "neck.quaternion";
        }

        if (track.name.includes("Spine")) {
            track.name = "spine2.quaternion";
        }

        return track;
    });

    useEffect(() => {

        let idleClipAction = mixer.clipAction(idleClips[0]);
        idleClipAction.play();

        let additionalIdleAction = mixer.clipAction(additionalIdleClips[0]);
        additionalIdleAction.play();

        let blinkClip = createAnimation(blinkData, morphTargetDictionaryBody, 'Wolf3D_Head');
        let blinkAction = mixer.clipAction(blinkClip);
        blinkAction.play();

        if (playing === true) {
            idleClipAction.stop();
            // additionalIdleAction.play();
        }
        else {
            additionalIdleAction.stop();
            idleClipAction.play();
        }
    }, [playing]);

    // Play animation clips when available
    useEffect(() => {
        if (playing === false)
            return;

        _.each(clips, clip => {
            let clipAction = mixer.clipAction(clip);
            clipAction.setLoop(THREE.LoopOnce);
            clipAction.play();

        });

    }, [playing]);


    useFrame((state, delta) => {
        mixer.update(delta);
    });


    return (
        <group name="avatar" position={[0.05, 1.35, 0]} scale={0.25}>
            <primitive object={gltf.scene} dispose={null} />
        </group>
    );
}




const STYLES = {
    area: { position: 'absolute', bottom: '10px', left: '10px', zIndex: 500 },
    text: { margin: '0px', width: '300px', padding: '5px', background: 'none', color: '#ffffff', fontSize: '1.2em', border: 'none' },
    speak: { padding: '10px', marginTop: '5px', display: 'block', color: '#FFFFFF', background: '#222222', border: 'None' },
    area2: { position: 'absolute', top: '5px', right: '15px', zIndex: 500 },
    label: { color: '#777777', fontSize: '0.8em' }
}

async function makeSpeech(blendData, fileName) {
    try {
        const response = await fetch(blendData); // Accessing the file from the public folder
        const data = await response.json();
        return {
            "data": data,
            "fileName": fileName
        }
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

export default function NextPage() {
    const location = useLocation();
    const mobile = location.state.mobile;
    const custName = location.state.custName;
    const dob = location.state.dob;
    const selectedOptionProduct = location.state.selectedOptionProduct;
    const selectedOptionPlan = location.state.selectedOptionPlan;
    const selectedOptionPayFor = location.state.selectedOptionPayFor;
    const selectedOptionPolicyDuration = location.state.selectedOptionPolicyDuration;
    const invFrequency = location.state.invFrequency;
    const invValue = location.state.invValue;

    const audioPlayer = useRef();

    const [speak, setSpeak] = useState(false);
    const [speakPDF, setSpeakPDF] = useState(false);
    const [speakpayment, setSpeakPayment] = useState(false);

    const [text, setText] = useState("My name is Arwen. I'm a virtual human who can speak whatever you type here along with realistic facial movements.");
    const [audioSource, setAudioSource] = useState(null);
    const [playing, setPlaying] = useState(false);



    // End of play
    function playerEnded(e) {
        setAudioSource(null);

        setSpeak(false);
        setSpeakPDF(false)
        setSpeakPayment(false)

        setPlaying(false);
    }

    // Player is read
    function playerReady(e) {
        audioPlayer.current.audioEl.current.play();
        setPlaying(true);
    }

    useEffect(() => {
        setSpeak(true);
        setSpeakPDF(true);
    }, [speak]);

    const navigate = useNavigate();

    const handlePayment = () => {
        setSpeak(true);
        setSpeakPayment(true);
        navigate('/finalpage');
    }

    const [pdfUrl, setPdfUrl] = useState('');


    const formData = {
        "Policy_holder_name": custName,
        "Date_of_birth": dob,
        "phone_number": mobile,
        "policy_term": selectedOptionPolicyDuration,
        "policy_payment_term": selectedOptionPayFor,
        "Annualized_Premium": invValue,
        "mode": invFrequency,
        "Option": selectedOptionPlan
    }
   


    useEffect(() => {
        async function fetchData() {
            console.log(formData)
            try {
                const apiurldetails = 'https://18s7vecqgc.execute-api.ap-south-1.amazonaws.com/avatar/pdf';

                const response = await fetch(apiurldetails, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/pdf',
                    },
                    body: JSON.stringify(formData),
                })

                const data = await response.json();
                console.log(data)
                const base64Res = data.BASE64;

                openImageInNewTab(base64Res);
            } catch (error) {
                console.error('Error fetching data', error);
            }
        }

        fetchData();
    }, []);

    const openImageInNewTab = (base64Res) => {
        const binaryData = atob(base64Res);
        console.log(binaryData)
        const arrayBuffer = new ArrayBuffer(binaryData.length);
        const uint8Array = new Uint8Array(arrayBuffer);

        for (let i = 0; i < binaryData.length; i++) {
            uint8Array[i] = binaryData.charCodeAt(i);
        }
        let blob = new Blob([uint8Array], { type: 'application/pdf' });

        const imageUrl = URL.createObjectURL(blob);

        setPdfUrl(imageUrl);

    };

    const [wait, setWait] = useState('');
    let [paymentDisable, setPaymentDisable] = useState(true);

    const [showpdf, setShowPdf] = useState(true)
    const [showpayment, setShowpayment] = useState(false)

    const openPdf = () => {
        console.log(pdfUrl);

        if (pdfUrl) {
            // const newTab = window.open(pdfUrl, '_blank');
            // newTab.focus();
            
            console.log("object")
            
            setSpeak(true);
            setSpeakPayment(true);

            // setShowPdf(false);
            // setShowpayment(true);

        } else {
            setWait('Please Wait!')

            setTimeout(() => {
                const newTab = window.open(pdfUrl, '_blank');
                newTab.focus();

                setTimeout(() => {
                    setSpeak(true);
                    setSpeakPayment(true);

                    setShowPdf(false);
                    setShowpayment(true);
                }, 2000);

            }, 4000)
        }
    };

    return (
        <>
            <div id='main-div'>

                <div id="leftdiv">


                    {showpdf &&
                        <div>
                            <button className='btn' id="pdfbutton" onClick={openPdf}>BI PDF GENERATE</button>
                            <p>{wait}</p>
                        </div>
                    }


                    {!showpdf &&
                        <button className='btn btn-primary' id="paymentbutton" onClick={handlePayment}>PAYMENT</button>
                    }



                </div>

                <ReactAudioPlayer
                    src={audioSource}
                    ref={audioPlayer}
                    onEnded={playerEnded}
                    onCanPlayThrough={playerReady}

                />

                {/* <Stats /> */}
                <Canvas id="canvas" style={{ 'top': '0vh' }} dpr={2} onCreated={(ctx) => {
                    ctx.gl.physicallyCorrectLights = true;
                }}>

                    <OrthographicCamera
                        makeDefault
                        zoom={1500}
                        position={[0, 1.65, 0.5]}
                    />

                    {/* <OrbitControls
                     target={[0, 1.65, 0]}
                    /> */}

                    <Suspense fallback={null}>
                        <Environment background={false} files="/images/photo_studio_loft_hall_1k.hdr" />
                    </Suspense>

                    {/* <Suspense fallback={null}>
                        <Bg />
                    </Suspense> */}

                    <Suspense fallback={null}>


                        <Avatar
                            avatar_url="/new.glb"
                            speak={speak}
                            setSpeak={setSpeak}

                            speakPDF={speakPDF}
                            setSpeakPDF={setSpeakPDF}

                            speakpayment={speakpayment}
                            setSpeakPayment={setSpeakPayment}

                            text={text}
                            setAudioSource={setAudioSource}
                            playing={playing}
                        />


                    </Suspense>



                </Canvas>
                <Loader dataInterpolation={(p) => `Loading... please wait`} />

            </div>
        </>


    )
}



function Bg() {

    const texture = useTexture('/images/bggrey.png');
    const viewport = useThree((state) => state.viewport);

    return (
        <mesh position={[0, 1.65, -1]} scale={[1, 1, 1]}>
            {/* <planeBufferGeometry /> */}
            <planeGeometry args={[viewport.width, viewport.height]} />
            <meshBasicMaterial map={texture} />

        </mesh>
    )

}