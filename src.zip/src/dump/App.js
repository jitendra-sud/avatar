import React, { Suspense, useEffect, useRef, useState, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { useGLTF, useTexture, Loader, Environment, useFBX, useAnimations, OrthographicCamera } from '@react-three/drei';
import { MeshStandardMaterial } from 'three/src/materials/MeshStandardMaterial';

import { LinearEncoding, sRGBEncoding } from 'three/src/constants';
import { LineBasicMaterial, MeshPhysicalMaterial, Vector2 } from 'three';
import ReactAudioPlayer from 'react-audio-player';

import createAnimation from './converter';
import blinkData from './blendDataBlink.json';

import * as THREE from 'three';
import axios from 'axios';
// import { setDeep } from '@react-three/fiber/dist/declarations/src/core/utils';
import './App.css'
import { FaArrowRight } from "react-icons/fa";
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
import NextPage from './NextPage';
import Finalpage from './Finalpage.js';
import Firstpage from './Firstpage.js';


const _ = require('lodash');

const host = 'http://localhost:5000'

function Avatar({ avatar_url, speak, setSpeak, speakInvalidMobile,setSpeakInvalidMobile, speakEmail, setSpeakEmail, speakIntro, setSpeakIntro, speakName, setSpeakName, speakNumber, setSpeakNumber, speakDOB, setSpeakDOB, speakProd, setSpeakProd, speakPdConfirm, setSpeakPdConfirm, text, setAudioSource, playing }) {

  let gltf = useGLTF(avatar_url);
  let morphTargetDictionaryBody = null;
  let morphTargetDictionaryLowerTeeth = null;

  const [
    bodyTexture,
    eyesTexture,
    teethTexture,
    bodySpecularTexture,
    bodyRoughnessTexture,
    bodyNormalTexture,
    teethNormalTexture,
    // teethSpecularTexture,
    hairTexture,
    tshirtDiffuseTexture,
    tshirtNormalTexture,
    tshirtRoughnessTexture,
    hairAlphaTexture,
    hairNormalTexture,
    hairRoughnessTexture,
  ] = useTexture([
    "/images/body.webp",
    "/images/eyes.webp",
    "/images/teeth_diffuse.webp",
    "/images/body_specular.webp",
    "/images/body_roughness.webp",
    "/images/body_normal.webp",
    "/images/teeth_normal.webp",
    // "/images/teeth_specular.webp",
    "/images/h_color.webp",
    "/images/tshirt_diffuse.webp",
    "/images/tshirt_normal.webp",
    "/images/tshirt_roughness.webp",
    "/images/h_alpha.webp",
    "/images/h_normal.webp",
    "/images/h_roughness.webp",
  ]);

  _.each([
    bodyTexture,
    eyesTexture,
    teethTexture,
    teethNormalTexture,
    bodySpecularTexture,
    bodyRoughnessTexture,
    bodyNormalTexture,
    tshirtDiffuseTexture,
    tshirtNormalTexture,
    tshirtRoughnessTexture,
    hairAlphaTexture,
    hairNormalTexture,
    hairRoughnessTexture
  ], t => {
    t.encoding = sRGBEncoding;
    t.flipY = false;
  });

  bodyNormalTexture.encoding = LinearEncoding;
  tshirtNormalTexture.encoding = LinearEncoding;
  teethNormalTexture.encoding = LinearEncoding;
  hairNormalTexture.encoding = LinearEncoding;


  gltf.scene.traverse(node => {


    if (node.type === 'Mesh' || node.type === 'LineSegments' || node.type === 'SkinnedMesh') {

      node.castShadow = true;
      node.receiveShadow = true;
      node.frustumCulled = false;


      if (node.name.includes("Body")) {

        node.castShadow = false;
        node.receiveShadow = false;

        node.material = new MeshPhysicalMaterial();
        node.material.map = bodyTexture;
        // node.material.shininess = 60;
        node.material.roughness = 1.7;

        // node.material.specularMap = bodySpecularTexture;
        node.material.roughnessMap = bodyRoughnessTexture;
        node.material.normalMap = bodyNormalTexture;
        node.material.normalScale = new Vector2(0.6, 0.6);

        morphTargetDictionaryBody = node.morphTargetDictionary;

        node.material.envMapIntensity = 0.8;
        // node.material.visible = false;

      }

      if (node.name.includes("Eyes")) {
        node.material = new MeshStandardMaterial();
        node.material.map = eyesTexture;
        // node.material.shininess = 100;
        node.material.roughness = 0.1;
        node.material.envMapIntensity = 0.5;


      }

      if (node.name.includes("Brows")) {
        node.material = new LineBasicMaterial({ color: 0x000000 });
        node.material.linewidth = 1;
        node.material.opacity = 0.5;
        node.material.transparent = true;
        node.visible = false;
      }

      if (node.name.includes("Teeth")) {

        node.receiveShadow = true;
        node.castShadow = true;
        node.material = new MeshStandardMaterial();
        node.material.roughness = 0.1;
        node.material.map = teethTexture;
        node.material.normalMap = teethNormalTexture;

        node.material.envMapIntensity = 0.7;


      }

      if (node.name.includes("Hair")) {
        node.material = new MeshStandardMaterial();
        node.material.map = hairTexture;
        node.material.alphaMap = hairAlphaTexture;
        node.material.normalMap = hairNormalTexture;
        node.material.roughnessMap = hairRoughnessTexture;

        node.material.transparent = true;
        node.material.depthWrite = false;
        node.material.side = 2;
        node.material.color.setHex(0x000000);

        node.material.envMapIntensity = 0.3;


      }

      if (node.name.includes("TSHIRT")) {
        node.material = new MeshStandardMaterial();

        node.material.map = tshirtDiffuseTexture;
        node.material.roughnessMap = tshirtRoughnessTexture;
        node.material.normalMap = tshirtNormalTexture;
        node.material.color.setHex(0xffffff);

        node.material.envMapIntensity = 0.5;


      }

      if (node.name.includes("TeethLower")) {
        morphTargetDictionaryLowerTeeth = node.morphTargetDictionary;
      }

    }

  });

  const [clips, setClips] = useState([]);
  const mixer = useMemo(() => new THREE.AnimationMixer(gltf.scene), []);

  useEffect(() => {
    let blendData = '';
    let fileName = '';

    if (speakIntro === false) return;

    blendData = '/audioFiles/Introduction/introduction.txt';
    fileName = '/speech-ijxtv.mp3';

    makeSpeechintro(blendData, fileName)
      .then(response => {
        console.log(response)

        // console.log(response.data.fileName)

        let blendData = response.data.blendData;
        let filename = response.fileName;

        let newClips = [
          createAnimation(blendData, morphTargetDictionaryBody, 'HG_Body'),
          createAnimation(blendData, morphTargetDictionaryLowerTeeth, 'HG_TeethLower')];

        filename = host + filename;

        console.log(filename)

        // lipsing data
        setClips(newClips);
        // audio data
        setAudioSource(filename);


      })
      .catch(err => {
        console.error(err);
        setSpeakIntro(false);
      })


  }, [speakIntro]);

  useEffect(() => {
    let blendData = '';
    let fileName = '';
    if (speak === false) return;

    if (speakIntro === true) {
      blendData = '/audioFiles/Introduction/introduction.txt';
      fileName = '/speech-ijxtv.mp3';
    } else if (speakName === true) {
      blendData = '/audioFiles/Name/name.txt';
      fileName = '/speech-vlceg.mp3';
      console.log("inside speak name")
    } else if (speakNumber === true) {
      blendData = '/audioFiles/Phone Number/phone.txt';
      fileName = '/speech-tpv8z.mp3';
    } else if (speakDOB === true) {
      blendData = '/audioFiles/DOB/dob.txt';
      fileName = '/speech-xs15o.mp3';
    } else if (speakProd === true) {
      blendData = '/audioFiles/Reccomendation/reccomendation.txt';
      fileName = '/speech-65j1x.mp3';
    } else if (speakPdConfirm === true) {
      blendData = '/audioFiles/Product Confirmation/productconfirm.txt';
      fileName = '/speech-764c4.mp3';
    } else if(speakEmail === true){
      blendData = '/audioFiles/Email_Id/email_id.txt';
      fileName = '/speech-rqn75.mp3';
    } else if(speakInvalidMobile === true){
      console.log("object")
      blendData = '/audioFiles/mobile_number/phone_number_validation.txt';
      fileName = '/speech-y779d.mp3';
    }


    makeSpeech(blendData, fileName)
      .then(response => {
        console.log(response)


        let blendData = response.data.blendData;
        let filename = response.fileName;

        let newClips = [
          createAnimation(blendData, morphTargetDictionaryBody, 'HG_Body'),
          createAnimation(blendData, morphTargetDictionaryLowerTeeth, 'HG_TeethLower')];

        filename = host + filename;

        console.log(filename)

        setClips(newClips);
        setAudioSource(filename);

      })
      .catch(err => {
        console.error(err);
        setSpeak(false);
        setSpeakIntro(false);
        setSpeakName(false);
        setSpeakNumber(false);
        setSpeakDOB(false);
        setSpeakProd(false);
        setSpeakEmail(false);
        setSpeakInvalidMobile(false);
        setSpeakPdConfirm(false);
      })


  }, [speak]);

  let idleFbx = useFBX('/idle.fbx');
  let { clips: idleClips } = useAnimations(idleFbx.animations);

  idleClips[0].tracks = _.filter(idleClips[0].tracks, track => {
    return track.name.includes("Head") || track.name.includes("Neck") || track.name.includes("Spine2");
  });

  idleClips[0].tracks = _.map(idleClips[0].tracks, track => {

    if (track.name.includes("Head")) {
      track.name = "head.quaternion";
    }

    if (track.name.includes("Neck")) {
      track.name = "neck.quaternion";
    }

    if (track.name.includes("Spine")) {
      track.name = "spine2.quaternion";
    }

    return track;
  });

  useEffect(() => {

    let idleClipAction = mixer.clipAction(idleClips[0]);
    idleClipAction.play();

    let blinkClip = createAnimation(blinkData, morphTargetDictionaryBody, 'HG_Body');
    let blinkAction = mixer.clipAction(blinkClip);
    blinkAction.play();

  }, []);

  // Play animation clips when available
  useEffect(() => {
    if (playing === false)
      return;

    _.each(clips, clip => {
      let clipAction = mixer.clipAction(clip);
      clipAction.setLoop(THREE.LoopOnce);
      clipAction.play();

    });

  }, [playing]);


  useFrame((state, delta) => {
    mixer.update(delta);
  });


  return (
    <group name="avatar">
      <primitive object={gltf.scene} dispose={null} />
    </group>
  );
}




const STYLES = {
  area: { position: 'absolute', bottom: '10px', left: '10px', zIndex: 500 },
  text: { margin: '0px', width: '300px', padding: '5px', background: 'none', color: '#ffffff', fontSize: '1.2em', border: 'none' },
  speak: { padding: '10px', marginTop: '5px', display: 'block', color: '#FFFFFF', background: '#222222', border: 'None' },
  area2: { position: 'absolute', top: '5px', right: '15px', zIndex: 500 },
  label: { color: '#777777', fontSize: '0.8em' }
}

async function makeSpeech(blendData, fileName) {
  console.log(blendData)
  console.log(fileName)

  try {
    const response = await fetch(blendData); // Accessing the file from the public folder
    const data = await response.json();
    return {
      "data": data,
      "fileName": fileName
    }
  } catch (error) {
    console.error('Error fetching data:', error);
  }
  // return axios.post(host + '/talk', { text });
}

async function makeSpeechintro(blendData, fileName) {
  console.log(blendData)
  console.log(fileName)

  try {
    const response = await fetch(blendData); // Accessing the file from the public folder
    const data = await response.json();
    return {
      "data": data,
      "fileName": fileName
    }
  } catch (error) {
    console.error('Error fetching data:', error);
  }
  // return axios.post(host + '/talk', { text });
}



function Appp() {
  const audioPlayer = useRef();

  const [speak, setSpeak] = useState(false);
  const [speakIntro, setSpeakIntro] = useState(false);
  const [speakName, setSpeakName] = useState(false);
  const [speakNumber, setSpeakNumber] = useState(false);
  const [speakDOB, setSpeakDOB] = useState(false);
  const [speakPdConfirm, setSpeakPdConfirm] = useState(false);
  const [speakProd, setSpeakProd] = useState(false);
  const [speakEmail, setSpeakEmail] = useState(false);
  const [speakInvalidMobile, setSpeakInvalidMobile] = useState(false);

  const [text, setText] = useState("My name is Arwen. I'm a virtual human who can speak whatever you type here along with realistic facial movements.");
  const [audioSource, setAudioSource] = useState(null);
  const [playing, setPlaying] = useState(false);



  // End of play
  function playerEnded(e) {
    setAudioSource(null);
    setSpeak(false);
    setSpeakName(false);
    setSpeakNumber(false);
    setSpeakDOB(false)
    setSpeakProd(false)
    setSpeakPdConfirm(false)
    setSpeakIntro(false)
    setSpeakEmail(false)
    setSpeakInvalidMobile(false);
    setPlaying(false);
  }

  // Player is read
  function playerReady(e) {
    audioPlayer.current.audioEl.current.play();
    setPlaying(true);
  }

  // on page reload 
  // useEffect(() => {
  //   setSpeakIntro(true);

  //   // setTimeout(() => {
  //   //   setSpeakIntro(true);
  //   // },1000);

  // }, [])

  // useEffect(() => {
  //   function playerReady(e) {
  //     audioPlayer.current.audioEl.current.play();
  //     setPlaying(true);
  //   }
  //   // setSpeak(true);
  //   setSpeakIntro(true);
  // },[]);



  // const [selectedOptionProduct, setSelectedOptionProoduct] = useState(''); // State to store the selected value
  // const handleSelectChangeProduct = (event) => {
  //   setSelectedOptionProoduct(event.target.value); // Update the selected value in state
  // };

  const [selectedOptionTerm, setSelectedOptionTerm] = useState(''); // State to store the selected value
  const handleSelectChangeTerm = (event) => {
    setSelectedOptionTerm(event.target.value); // Update the selected value in state
  };


  const [selectedOptionPremium, setSelectedOptionPremium] = useState(''); // State to store the selected value
  const handleSelectChangePremium = (event) => {
    setSelectedOptionPremium(event.target.value); // Update the selected value in state
  };

  const [selectedOptionPlan, setSelectedOptionPlan] = useState(''); // State to store the selected value
  const handleSelectChangePlan = (event) => {
    setSelectedOptionPlan(event.target.value); // Update the selected value in state
  };

  const [selectedOptionPolicyDuration, setSelectedOptionPolicyDuration] = useState('');
  const handleSelectChangePolicyDuration = (event) => {
    setSelectedOptionPolicyDuration(event.target.value);
  }

  const [selectedOptionPayFor, setSelectedOptionPayFor] = useState('');
  const handleSelectChangePayFor = (event) => {
    setSelectedOptionPayFor(event.target.value);
  }
  
  const [invValue,setInvValue] = useState('');
  const [invFrequency,setInvFrequency] = useState('');

  const [selectedOptionProduct, setSelectedOptionProduct] = useState('');
  const [showPopup, setShowPopup] = useState(false);
  const [selectedProductImage, setSelectedProductImage] = useState('');

  const handleSelectChangetInvFreq = (event) => {
    setInvFrequency(event.target.value)
  }

  const handleSelectChangeProduct = (event) => {
    const selectedValue = event.target.value;
    setSelectedOptionProduct(selectedValue);

    // Set the image source based on the selected option
    if (selectedValue === 'option1') {
      setSelectedProductImage('./option1.png');
    } else if (selectedValue === 'option2') {
      setSelectedProductImage('./option2.png');
    }
    // Add conditions for other options as needed

    setShowPopup(!!selectedValue);
  };

  const closePopup = () => {
    setShowPopup(false);
  };




  const [nameWrn, setNameWrn] = useState(false);
  const [mobWrn, setMobWrn] = useState(false);
  const [dobWrn, setdobWrn] = useState(false);
  const [emailWrn, setemailWrn] = useState(false);
  const [prodDiv, setProdDiv] = useState(false);



  function speakNameFunc() {

    setNameWrn(false);
    if (custName.length === 0) {
      setNameWrn(true);
    } else {
      setNameWrn(false);
      setSpeak(true)
      setSpeakName(true);
    }


    setTimeout(() => {
      if (custName && mobile && dob && email) {
        setSpeak(true);
        setSpeakProd(true);
        setProdDiv(true);
      }
    }, 4000);
  }

  function speakMobNoFunc() {

    setMobWrn(false);
    console.log(mobile.length)
    if (mobile.length !== 10) {
      setMobWrn(true);
      setSpeak(true);
      setSpeakInvalidMobile(true);      
    } else {
      setMobWrn(false);
      setSpeak(true);
      setSpeakNumber(true);
    }


    setTimeout(() => {
      if (custName && mobile && dob && email) {
        console.log(custName, mobile, dob)
        setSpeak(true);
        setSpeakProd(true);
        setProdDiv(true);
      }
    }, 4000);
  }

  function speakDOBFunc() {


    setdobWrn(false);
    if (dob.length === 0) {
      setdobWrn(true);
    } else {
      setdobWrn(false);
      setSpeak(true);
      setSpeakDOB(true);
    }

    setTimeout(() => {
      if (custName && mobile && dob && email) {
        console.log(custName, mobile, dob)
        setSpeak(true);
        setSpeakProd(true);
        setProdDiv(true);
      }
    }, 4000);

  }

  function speakEmailFunction() {
    setSpeakEmail(false);
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const isValid = regex.test(email);
    if (!isValid) {
      setemailWrn(true);
    } else {
      setemailWrn(false);
      setSpeak(true);
      setSpeakEmail(true);
    }

    setTimeout(() => {
      if (custName && mobile && dob && email) {
        console.log(custName, mobile, dob, email)
        setSpeak(true);
        setSpeakProd(true);
        setProdDiv(true);
      }
    }, 4000);

  }

  const [custName, setCustName] = useState("");
  const [mobile, setMobile] = useState("");
  const [dob, setDob] = useState("");
  const [email, setEmail] = useState("")



  const navigate = useNavigate();

  const handleSubmit = () => {
    setSpeak(true);
    setSpeakPdConfirm(true);

    console.log(custName, mobile, dob, email, selectedOptionProduct, selectedOptionPlan, selectedOptionPolicyDuration,selectedOptionPayFor, invFrequency, invValue  )

    setTimeout(() => {

      navigate('/nextpage', { state: { mobile: mobile, custName: custName, dob: dob, email:email, selectedOptionProduct: selectedOptionProduct, selectedOptionPlan: selectedOptionPlan, selectedOptionPayFor: selectedOptionPayFor, selectedOptionPolicyDuration: selectedOptionPolicyDuration, invFrequency: invFrequency, invValue: invValue } });
    }, 9000);
  }

  // useEffect(() => {
  //   // Check if the audio element exists
  //   if (audioSource.current) {
  //     // Start audio playback
  //     audioSource.current.play().catch(error => {
  //       // Handle the error if autoplay is blocked
  //       console.error('Autoplay blocked:', error);
  //       // Show a message or ask the user to interact with the page
  //     });
  //   }
  // }, []);

  const [blur, setBlur] = useState(false);

  const toggleBlur = () => {
    setBlur(true);
    setSpeakIntro(true);
  };

  // const history = useNavigate();

  // useEffect(() => {
  //   const unblock = history.block(() => {
  //     // Prevent navigating back by pushing the current location again
  //     history.push('/');
  //     return false; // Return false to prevent navigation
  //   });

  //   return () => {
  //     unblock(); // Clean up the blocking function when the component unmounts
  //   };
  // }, [history]);

  return (
    <div>

      {!blur &&
        <button onClick={toggleBlur} className="blur-button">
          CLICK FOR BOLP
        </button>
      }

      <div id='main-div' className={` ${!blur ? 'blurred' : ''}`} >

        <div >
          <div style={STYLES.area}>
            {/* <textarea rows={4} type="text" style={STYLES.text} value={text} onChange={(e) => setText(e.target.value.substring(0, 200))} /> */}
            {/* <button style={STYLES.speak}> {speak ? 'Running...' : 'Speak'}</button> */}

            <div id="firstbox" >
              <input type="text" placeholder="Name..." onChange={(e) => setCustName(e.target.value)} />
              <button onClick={speakNameFunc} id="arrow">  <FaArrowRight /></button>
              {/* <button type="submit" onClick={() => setSpeakName(true)}>Search</button> */}
              {nameWrn &&
                <div id="nameWarning">Please Provide Name!!</div>
              }
            </div>

            <div id="firstbox" >
              <input type="mobile" placeholder="Mobile Number..." onChange={(e) => setMobile(e.target.value)} />
              <button onClick={speakMobNoFunc} id="arrow">  <FaArrowRight /></button>
              {/* <button type="submit">Search</button> */}
              {mobWrn &&
                <div id="nameWarning">Please Provide Valid Mobile Number!!</div>
              }
            </div>

            <div id="firstbox" >
              <input type="date"  placeholder="DOB..." onChange={(e) => setDob(e.target.value)} />
              <button onClick={speakDOBFunc} id="arrow">  <FaArrowRight /></button>
              {/* <button type="submit">Search</button> */}
              {dobWrn &&
                <div id="nameWarning">Please Provide DOB!!</div>
              }
            </div>

            <div id="firstbox" >
              <input type="email" placeholder="Email id..." onChange={(e) => setEmail(e.target.value)} />
              <button onClick={speakEmailFunction} id="arrow">  <FaArrowRight /></button>
              {/* <button type="submit">Search</button> */}
              {emailWrn &&
                <div id="nameWarning">Please Provide Email!!</div>
              }
            </div>

            {prodDiv &&
              <div id="prductdiv">

                <div id="firstboxproduct" >
                  {/* <input type="search" placeholder="Product..." /> */}
                  <select id="product" value={selectedOptionProduct} onChange={handleSelectChangeProduct}>
                    <option value="">Select A Product</option>
                    <option value="SUDlife E-Wealth Royal">SUDlife E-Wealth Royal</option>
                    <option value="SUDlife Praptee">SUDlife Praptee</option>
                    <option value="SUDlife Samridhhi">SUDlife Samridhhi</option>
                  </select>
                  {/* <button type="submit">Search</button> */}
                </div>


                {showPopup && (
                  <div className="popup">
                    <span id="popupspan" className="close" onClick={closePopup}>&times;</span>
                    <img id="popupimage" src={selectedProductImage} alt="Product Image" />
                  </div>
                )}

                <div id="firstboxproduct" >
                  {/* <input type="search" placeholder="Product..." /> */}
                  <select id="product" value={selectedOptionPlan} onChange={handleSelectChangePlan}>
                    <option value="">Select A Plan</option>
                    <option value="Preminum">Preminum</option>
                    <option value="Preminum Plus">Preminum Plus</option>
                  </select>
                  {/* <button type="submit">Search</button> */}
                </div>

                <div id="firstboxPremium"  >
                  <select id="product" style={{ 'width': '12vw' }} value={selectedOptionPolicyDuration} onChange={handleSelectChangePolicyDuration}>
                    <option value="">Policy Duration</option>
                    <option value="10 Year">10 Year</option>
                    <option value="11 Year">11 Year</option>
                    <option value="12 Year">12 Year</option>
                    <option value="13 Year">13 Year</option>
                    <option value="14 Year">14 Year</option>
                    <option value="15 Year">15 Year</option>
                    <option value="16 Year">16 Year</option>
                    <option value="17 Year">17 Year</option>
                    <option value="18 Year">18 Year</option>
                    <option value="19 Year">19 Year</option>
                    <option value="20 Year">20 Year</option>
                    <option value="21 Year">21 Year</option>
                  </select>

                  <select id="product" style={{ 'width': '12vw', 'left': '1vw' }} value={selectedOptionPayFor} onChange={handleSelectChangePayFor}>
                    <option value="">Pay For</option>
                    <option value="5 Year">5 Year</option>
                    <option value="7 Year">7 Year</option>
                    <option value="10 Year">10 Year</option>
                    <option value="20 Year">20 Year</option>
                  </select>
                </div>

                <div id="firstboxTerm" >
                  <input id="product"  style={{ 'width': '12vw' }} placeholder="Investment Value" onChange={e => {setInvValue(e.target.value)}} />
                  {/* <input id="product" style={{ 'width': '12vw', 'left': '1vw' }} placeholder="Investment frequency" onChange={e => {setInvFrequency(e.target.value)}} /> */}
                  <select id="product" style={{ 'width': '12vw', 'left': '1vw' }} value={invFrequency} onChange={handleSelectChangetInvFreq}>
                    <option value="">Investment frequency</option>
                    <option value="Monthly">Monthly</option>
                    <option value="Quaterly">Quaterly</option>
                    <option value="Semi-Annual">Semi-Annual</option>
                    <option value="Annual">Annual</option>
                  </select>
                 
                </div>
                <button className='btn btn-success' id="submit" onClick={handleSubmit}>Submit</button>
              </div>
            }




          </div>

        </div>

        {/* <audio ref={audioSource} src="speech-ijxtv.mp3" /> */}

        {/* {console.log(audioSource)} */}
        <ReactAudioPlayer
          src={audioSource}
          ref={audioPlayer}
          onEnded={playerEnded}
          onCanPlayThrough={playerReady}
        />



        {/* <Stats /> */}
        <Canvas id="canvas" dpr={2} onCreated={(ctx) => {
          ctx.gl.physicallyCorrectLights = true;
        }}>

          <OrthographicCamera
            makeDefault
            zoom={2000}
            position={[0, 1.65, 1]}
          />

          {/* <OrbitControls
  target={[0, 1.65, 0]}
    /> */}

          <Suspense fallback={null}>
            <Environment background={false} files="/images/photo_studio_loft_hall_1k.hdr" />
          </Suspense>

          <Suspense fallback={null}>
            <Bg />
          </Suspense>

          <Suspense fallback={null}>



            <Avatar
              avatar_url="/model.glb"
              speak={speak}
              setSpeak={setSpeak}

              speakName={speakName}
              setSpeakName={setSpeakName}

              speakNumber={speakNumber}
              setSpeakNumber={setSpeakNumber}

              speakDOB={speakDOB}
              setSpeakDOB={setSpeakDOB}

              speakProd={speakProd}
              setSpeakProd={setSpeakProd}

              speakPdConfirm={speakPdConfirm}
              setSpeakPdConfirm={setSpeakPdConfirm}

              speakIntro={speakIntro}
              setSpeakIntro={setSpeakIntro}

              speakEmail={speakEmail}
              setSpeakEmail={setSpeakEmail}

              speakInvalidMobile = {speakInvalidMobile}
              setSpeakInvalidMobile={setSpeakInvalidMobile}

              text={text}
              setAudioSource={setAudioSource}
              playing={playing}
            />


          </Suspense>



        </Canvas>
        <Loader dataInterpolation={(p) => `Loading... please wait`} />

      </div>
    </div>

  )
}

// import Finalpage from './Finalpage.js';


function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/firstpage" element={<Appp />}></Route>
        <Route path="/nextpage" element={<NextPage />}></Route>
        <Route path="/finalpage" element={<Finalpage />}></Route>
        <Route path="/" element={<Firstpage />}></Route>

      </Routes>
    </BrowserRouter>
  )
}

function Bg() {

  const texture = useTexture('/images/bg.webp');

  return (
    <mesh position={[0, 1.5, -2]} scale={[0.8, 0.8, 0.8]}>
      <planeBufferGeometry />
      <meshBasicMaterial map={texture} />

    </mesh>
  )

}

export default App;
